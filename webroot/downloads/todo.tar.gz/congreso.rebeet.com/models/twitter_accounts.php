<?php
class TwitterAccounts extends AppModel {

	var $name = 'TwitterAccounts';
	
	var $useTable = 'twitter_accounts'; 
}
?>