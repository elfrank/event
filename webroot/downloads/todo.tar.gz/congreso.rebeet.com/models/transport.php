<?php
class Transport extends AppModel {

	var $name = 'Transport';
}
?>