-- MySQL dump 10.13  Distrib 5.1.37, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: authcake
-- ------------------------------------------------------
-- Server version	5.1.37-1ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `short_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `long_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `contenttype_id` int(30) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (9,1,'Desarrollo en Android','Desarrollo en Android','',1,'2010-03-14 15:48:19','2010-04-28 20:12:51',0,0),(10,1,'Desarrollo para iPhone','Desarrollo para iPhone','En este taller se presenta el software developer kit para el iPhone, se proporciona la informaciÃƒÂ³n necesaria para empezar a desarrollar software en esta plataforma, asÃƒÂ­ como una demostraciÃƒÂ³n de su uso. Se asume que el participante tiene conocimiento de programaciÃƒÂ³n orientada a objetos y de programaciÃƒÂ³n en general.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(11,1,'AJAX BÃƒÂ¡sico','AJAX BÃƒÂ¡sico','El taller es una introducciÃƒÂ³n a la tecnologÃƒÂ­a AJAX. Se abordarÃƒÂ¡n ejemplos y el participante podrÃƒÂ¡ jugar y explorar con esta tecnologÃƒÂ­a utilizada para el desarrollo web.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(12,1,'Adobe Flex','Adobe Flex','Taller enfocado a diseÃƒÂ±adores y/o desarrolladores que quieran conocer Flex para realizar aplicaciones RIA. Se enseÃƒÂ±an los fundamentos de esta tecnologÃƒÂ­a para hacer layouts de aplicaciones y consumir datos externos.\r\n\r\nNivel: BÃƒÂ¡sico (recomendado conocimientos de XML y programaciÃƒÂ³n bÃƒÂ¡sica)',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(13,1,'Asterisk','Asterisk','',1,'2010-03-14 15:48:19','2010-04-28 20:13:54',0,0),(14,1,'Drupal - Creando portales dinÃƒÂ¡micos y comunidades virtual','Drupal - Creando portales dinÃƒÂ¡micos y comunidades virtuales','En el taller aprenderemos sobre Drupal, uno de los mejores manejadores de contenidos (CMS) que existen actualmente. Revisaremos el flujo de trabajo y como es que Drupal hace para manejar el contenido y agregarle funcionalidad a los sitios. Revisaremos los mÃƒÂ³dulos mas importantes y usados. Por ultimo crearemos un sitio de desarrollo que incluirÃƒÂ¡ todos los elementos bÃƒÂ¡sicos de Drupal. ',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(15,1,'MoCap: Motion Capture','MoCap: Motion Capture','Los conceptos captura de movimiento, seguimiento de movimiento, o simplemente mocap (por su nombre en inglÃƒÂ©s), son utilizados para describir el proceso de capturar movimientos y traducirlos a un modelo digital. En otras palabras capturar las acciones de actores humanos y utilizar esta informaciÃƒÂ³n para animar modelos digitales de caracteres en dos o tres dimensiones a travÃƒÂ©s de una computadora. Estos procesos comprenden desde movimientos corporales hasta movimientos tan finos como gestos con las manos, dedos e incluso expresiones faciales. Mocap es utilizado en la milicia, la industria del entretenimiento y los deportes, aplicaciones mÃƒÂ©dicas y la industria cinematogrÃƒÂ¡fica. Entre otras cosas para:\r\n\r\n- Videojuegos. Los videojuegos usan con mucha frecuencia movimientos capturados para animar atletas, movimientos de artes marciales, y otras acciones que deban lucir como humanas (bailar, abrazar, caer, saltar, etc).\r\n- PelÃƒÂ­culas. En esta industria se utiliza la captura de movimiento para crear creaturas completamente animadas por computadoras, como el caso de los personajes: Jar-Jar Binks, Gollum, La Momia, King-Kong y los NaÃ¢â‚¬â„¢vi de la pelÃƒÂ­cula Avatar. ? Realidad virtual. La captura de movimiento permite que los usuarios interactÃƒÂºen con contenidos digitales en tiempo real. Esto se utiliza en simuladores, exÃƒÂ¡menes de percepciÃƒÂ³n visual y para realizar recorridos virtuales en ambiente tridimensionales.\r\n\r\nObjetivos\r\n\r\n1. IntroducciÃƒÂ³n a la captura de movimientos: Ã‚Â¿CÃƒÂ³mo funciona?\r\n2. Ejemplificar los principios bÃƒÂ¡sicos que sustentan la tecnologÃƒÂ­a de captura de movimiento\r\n3. Sistemas de captura de movimiento en 3D para animaciÃƒÂ³n, rehabilitaciÃƒÂ³n, simulaciÃƒÂ³n y entrenamiento. Trabajaremos con el sistema de Mocap inaugurado el 29 de noviembre pasado en el ITESM campus Guadalajara. Uno de los pocos sistemas de Mocap disponibles en MÃƒÂ©xico al alcance de estudiantes universitarios.\r\n4. Desarrollo de ideas simples para videojuegos y animaciÃƒÂ³n.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(16,1,'ProgramaciÃƒÂ³n de Robots con Java','ProgramaciÃƒÂ³n de Robots con Java','La robÃƒÂ³tica juega un papel muy importante en nuestro mundo los robots han hecho suyas de manera incremental aquellas tareas aburridas, costosas o que resultan peligrosas para ser desarrolladas por los humanos. Las habilidades de escuchar, ver, hablar y moverse son clave para que un humano pueda manipular el mundo que le rodea. Y para que un robot sea capaz de realizar tareas humanas debe de ser capaz de simular estas funciones a travÃƒÂ©s de software. Y cuando se trata de habilitar sistemas robustos, independientes del dispositivo o de la plataforma en que se ejecutan, la tecnologÃƒÂ­a de Java ha marcado la pauta a seguir. Java ofrece un conjunto de interfaces (APIs) que se ajustan a las necesidades demandadas por el ÃƒÂ¡rea de la robÃƒÂ³tica. Este tutorial es una introducciÃƒÂ³n prÃƒÂ¡ctica al mundo de la robÃƒÂ³tica, para ello combinamos la sencillez del hardware de LEGO Mindstorm NXT con el poder de programaciÃƒÂ³n de Java. Los temas que cubriremos en este tutorial son:\r\n\r\n1. InstalaciÃƒÂ³n de LeJOS, la MÃƒÂ¡quina Virtual de Java para LEGO Mindstorm NXT.\r\n2. ConfiguraciÃƒÂ³n del ambiente de desarrollo\r\n3. ManipulaciÃƒÂ³n de motores y sensores.\r\n4. ProgramaciÃƒÂ³n de comportamientos\r\n5. ComunicaciÃƒÂ³n inalÃƒÂ¡mbrica entre el robot y la computadora.\r\n6. ManipulaciÃƒÂ³n de Audio\r\n7. VisiÃƒÂ³n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(17,1,'Videojuegos en Adobe Flash','Videojuegos en Adobe Flash','Este taller estÃƒÂ¡ orientado a las personas que deseen aprender los conceptos esenciales para la creaciÃƒÂ³n de videojuegos en Flash utilizando su lenguaje de programaciÃƒÂ³n ActionScript 3.0 y las herramientas incluidas en la versiÃƒÂ³n CS4 de Adobe Flash.\r\n\r\nLos temas que se verÃƒÂ¡n van desde movimiento de objetos hasta trigonometrÃƒÂ­a de juegos, pasando por detecciÃƒÂ³n de colisiones, 3D en Flash, Tweens y mucho mucho mÃƒÂ¡s.\r\n\r\nLos requerimientos son los siguientes:\r\n\r\nÃ¢â‚¬Â¢	Saber utilizar la herramienta Adobe Flash a un nivel bÃƒÂ¡sico.\r\nÃ¢â‚¬Â¢	Nociones bÃƒÂ¡sicas de programaciÃƒÂ³n orientada a objetos.\r\nÃ¢â‚¬Â¢	MatemÃƒÂ¡ticas bÃƒÂ¡sicas\r\nÃ¢â‚¬Â¢	Haber trabajado con ActionScript (deseable)\r\n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(18,1,'Final Cut Studio Pro','Final Cut Studio Pro','Taller express de Final Cut Pro. Conoce una de las plataformas de ediciÃƒÂ³n de video mÃƒÂ¡s populares del momento. Aprende su correcta configuraciÃƒÂ³n de acuerdo a tus necesidades y\r\nconoce sus caracterÃƒÂ­sticas mÃƒÂ¡s usadas en la industria del video.\r\n\r\nComprenderemos el flujo de trabajo que debe seguirse en FCP desde el inicio de los proyectos para evitar complicaciones en etapas avanzadas de la post producciÃƒÂ³n. En una sola sesiÃƒÂ³n obtÃƒÂ©n de manera profesional las bases para trabajar de la mejor manera con FCP. Tips & Tricks.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(19,1,'AdministraciÃƒÂ³n de Proyectos','AdministraciÃƒÂ³n de Proyectos','En el nuevo mundo de las TI, administraciÃƒÂ³n de proyecto es uno de los skills cada vez mas requerido en los profesionales de las TI, CISC consiente de la nueva realidad ofrece el taller AdministraciÃƒÂ³n de Proyectos , conducido por Jorge JuÃƒÂ¡rez.\r\n<!--break-->\r\n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(20,1,'NVIDIA: CÃƒÂ³mputo Paralelo Avanzado y el Mundo Digital en 3','NVIDIA: CÃƒÂ³mputo Paralelo Avanzado y el Mundo Digital en 3D','Hoy en dÃƒÂ­a la verdadera velocidad en una PC ya no depende del procesador serial convencional (CPU) sino del procesador paralelo (GPU).   Sistemas que corren aplicaciones optimizadas para usar el GPU ofrecen un desempeÃƒÂ±o jamÃƒÂ¡s visto en el cÃƒÂ³mputo y permite a todo usuario desempeÃƒÂ±ar tareas que antes solo se podÃƒÂ­an imaginar.\r\n<!--break-->\r\nConoce:\r\n-	PCs aceleradas que facilitan la productividad, y simplifican la vida de desarrolladores de contenido digital (animaciones 3D, efectos especiales, codificaciÃƒÂ³n, ediciÃƒÂ³n de imÃƒÂ¡genes y fotografÃƒÂ­as,  correcciÃƒÂ³n de color en tiempo real, etc.). \r\n-	La tecnologÃƒÂ­a que acelerarÃƒÂ¡ las supercomputadoras mÃƒÂ¡s potentes del mundo y que permitirÃƒÂ¡ a un profesional poder construir su propia supercomputadora personal.\r\n-	La nueva generaciÃƒÂ³n de  dispositivos mÃƒÂ³viles Ã¢â‚¬â€œ siempre encendidas y conectadas al internet Ã¢â‚¬â€œcon una larga duraciÃƒÂ³n de baterÃƒÂ­a.  \r\n-	PCs portÃƒÂ¡tiles y de escritorio con gran capacidad que ejecutan sin problemas aplicaciones nuevas y a velocidades jamÃƒÂ¡s vistas.\r\n-	Video juegos absorbentes con efectos ultra-realistas en y hasta en 3 dimensiones con lentes estereoscÃƒÂ³picos.\r\n\r\nAGENDA DE EXPOSICIÃƒâ€œN \r\n\r\nUn AnÃƒÂ¡lisis sobre la Arquitectura Paralela de ÃƒÂºltima generaciÃƒÂ³n.\r\nÃ¢â‚¬Â¢	El Procesador Paralelo y comparaciÃƒÂ³n con el Procesador Serial\r\nÃ¢â‚¬Â¢	Arquitectura de CÃƒÂ³mputo Paralelo FERMI\r\nÃ¢â‚¬Â¢	Arquitectura de CÃƒÂ³mputo MÃƒÂ³vil Ultra-Ligera TEGRA\r\nÃ¢â‚¬Â¢	Los usos de las lÃƒÂ­neas de productos basados en los Procesadores Paralelos NVIDIA: Quadro, Tesla, GeForce\r\nÃ¢â‚¬Â¢	Programas y Aplicaciones de hoy y maÃƒÂ±ana que aprovechan al mÃƒÂ¡ximo el Paralelismo.\r\nÃ¢â‚¬Â¢	Efectos Ultra-Realistas con la tecnologÃƒÂ­a NVIDIA PhysX \r\nÃ¢â‚¬Â¢	El lenguaje de programaciÃƒÂ³n en GPU, NVIDIA CUDA\r\nÃ¢â‚¬Â¢	Demostraciones de tecnologÃƒÂ­as NVIDIA\r\nÃ¢â‚¬Â¢	NVIDIA 3DVision en AcciÃƒÂ³n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(21,1,'Modding Avanzado','Modding Avanzado','',1,'2010-03-14 15:48:19','2010-04-28 20:14:00',0,0),(22,1,'Modding BÃƒÂ¡sico','Modding BÃƒÂ¡sico','Taller en el cual se muestra el correcto acomodo de los cables, flujo de aire y sus repercusiones en el rendimiento del equipo.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(23,1,'DescripciÃƒÂ³n de tÃƒÂ©cnicas y mÃƒÂ©todos utilizados en el ','DescripciÃƒÂ³n de tÃƒÂ©cnicas y mÃƒÂ©todos utilizados en el diseÃƒÂ±o de software para aviÃƒÂ³nica','La construcciÃƒÂ³n de software para sistemas de aviÃƒÂ³nica requiere la aplicaciÃƒÂ³n de mÃƒÂ©todos de ingenierÃƒÂ­a que aseguren que el producto final, tanto el software mismo como el sistema completo, sea seguro. En muchas ocasiones incluso el software mismo provee de capacidades de seguridad (safety) al sistema que de otra manera no podrÃƒÂ­an ser construidos. En el taller se explicarÃƒÂ¡n los principales mÃƒÂ©todos y tÃƒÂ©cnicas utilizados y se realizarÃƒÂ¡n ejercicios donde estos sean aplicados.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(24,1,'Scripting en Ruby','Scripting en Ruby','Temas: \r\n\r\n- IntroducciÃƒÂ³n a ruby\r\n- Ruby viniendo de Java\r\n- Numeros, Strings, SÃƒÂ­mbolos y Diccionarios\r\n- Ciclos, condiciones\r\n- ProgramaciÃƒÂ³n Orientada a Objetos (clases)\r\n- MÃƒÂ©todos, parÃƒÂ¡metros\r\n- Herencia, Mixins y MÃƒÂ³dulos\r\n- Bloques e Iteradores\r\n- Clases abiertas\r\n\r\nDescripciÃƒÂ³n: En este taller aprenderÃƒÂ¡s a usar el lenguaje de programaciÃƒÂ³n Ruby. Ruby es un lenguaje de programaciÃƒÂ³n dinÃƒÂ¡mico orientado a objetos que se enfoca en la simplicidad y productividad. Tiene una sintaxis elegante que es fÃƒÂ¡cil de leer y mejor aÃƒÂºn de escribir.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(25,1,'Cloud Computing y Software On-Demand','Cloud Computing y Software On-Demand','El concepto de Multi-Tenancy es uno de los elementos centrales de las aplicaciones Cloud Computing y Software On-Demand. Una arquitectura de aplicaciÃƒÂ³n Multi-Tenant es aquella donde todos los usuarios de la aplicaciÃƒÂ³n, independientemente de la organizaciÃƒÂ³n (cliente) a la que pertenecen, comparten la misma instancia del cÃƒÂ³digo, de la base de datos y de la infraestructura. Esta arquitectura es lo que permite alcanzar las economÃƒÂ­as de escala que se traducen en costos competitivos para estos modelos de negocio. Adicionalmente, multi-tenancy abre la puerta al anÃƒÂ¡lisis de datos de uso de las aplicaciones de una manera que nunca antes habÃƒÂ­a sido posible para los proveedores de software. Esta charla les darÃƒÂ¡ a los asistentes conocimientos adicionales a los alumnos de universidad y reciÃƒÂ©n egresados la oportunidad  de explorar las nuevas tendencias en relaciÃƒÂ³n a la arquitectura de software.\r\n\r\nNivel del Taller: Intermedio en ProgramaciÃƒÂ³n y Arquitectura.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(26,1,'Ruby on Rails: Desarrollo ÃƒÂ¡gil de Aplicaciones','Ruby on Rails: Desarrollo ÃƒÂ¡gil de Aplicaciones','Temas:\r\n\r\n- PatrÃƒÂ³n Modelo Vista Controlador\r\n- Migraciones\r\n- Controladores, Modelos, Vistas\r\n- Validaciones automÃƒÂ¡ticas\r\n- Desarrollo de un recetario/blog/lista de TO-DOs\r\n\r\nDescripciÃƒÂ³n: Rails es una plataforma de desarrollo web que facilita el desarrollo de aplicaciones usando bases de datos como almacenes de informaciÃƒÂ³n. Utiliza el patrÃƒÂ³n MVC para dividir la presentaciÃƒÂ³n, los datos y el control de la aplicaciÃƒÂ³n. AprenderÃƒÂ¡s las bases de la plataforma desarrollando una aplicaciÃƒÂ³n que podrÃƒÂ¡s utilizar en tu vida diaria.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(27,1,'Visita Campus TecnolÃƒÂ³gico de IBM','Visita Campus TecnolÃƒÂ³gico de IBM',' Agenda: \r\n\r\n4.00pm - 5.00pm : Visita al GASC* y el GRIC* \r\n\r\n5.00pm - 6.00pm : Charla sobre Quality Management usando Rational Quality Manager por parte de Agueda Martinez \r\n\r\n6.00pm - 6.45pm : Charla sobre IBM Campus Guadalajara y Rational por parte del Ing. Arturo Jafet RodrÃƒÂ­guez \r\n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(28,1,'Programando con el iPhone SDK','Programando con el iPhone SDK','<ul>\r\n <li>Aprende sobre la arquitectura de software del iPhone</li>\r\n <li>Aprende sobre herramientas de desarrollo del iPhone y el lenguaje de ProgramaciÃƒÂ³n Objective-C</li>\r\n <li>Framework de Aplicaciones del iPhone</li>\r\n <li>DiseÃƒÂ±o de interfaces y buenas prÃƒÂ¡cticas en el desarrollo de Aplicaciones para el iPhone</li>\r\n <li>LocalizaciÃƒÂ³n, AceleraciÃƒÂ³n, OrientaciÃƒÂ³n e InformaciÃƒÂ³n del Sistema</li>\r\n <li>Fundamentos del iPhone para Desarrolladores Web</li>\r\n</ul>\r\n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(29,1,'OpenMP: Una IntroducciÃƒÂ³n al cÃƒÂ³mputo paralelo','OpenMP: Una IntroducciÃƒÂ³n al cÃƒÂ³mputo paralelo','Hoy en dÃƒÂ­a, las computadoras personales es comÃƒÂºn que contengan 2 o mÃƒÂ¡s nÃƒÂºcleos de procesamiento. Esto lleva capacidades de cÃƒÂ³mputo paralelo a las manos de todos los usuarios. Utilizando la herramienta OpenMP aprenderemos los conceptos bÃƒÂ¡sicos de cÃƒÂ³mputo paralelo y las ventajas de utilizar el procesamiento en mÃƒÂ¡s de un nÃƒÂºcleo.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(30,1,'CÃƒÂ³mputo Distribuido de Alto Rendimiento con MPI','CÃƒÂ³mputo Distribuido de Alto Rendimiento con MPI','La posibilidad de crear super computadoras a partir de equipos econÃƒÂ³micos ha hecho que la arquitectura de clÃƒÂºster se popularice. Nuevas arquitecturas requieren nuevas herramientas, y la interfaz de paso de mensajes (MPI) se encamina como la herramienta por excelencia para el cÃƒÂ³mputo de alto rendimiento. Durante el taller exploraremos dicha herramienta y cÃƒÂ³mo utilizarla para resolver problemas con altas necesidades de procesamiento.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(31,1,'IBM Rational Team Concert','IBM Rational Team Concert','La actual situaciÃƒÂ³n en la industria es que se ha comenzado a hacer uso de equipos distribuidos  y el tener total control sobre el desarrollo de software se esta haciendo mas difÃƒÂ­cil cada dÃƒÂ­a. Estamos viendo equipos que estÃƒÂ¡n interconectados en la organizaciÃƒÂ³n con diferentes arquitecturas y esto se hace cada vez mas presente en las organizaciones que desarrollan software. El desarrollar nuevos productos es un nicho crÃƒÂ­tico en la operativa diaria como a su vez lo es la entrega en tiempo. Las organizaciones de desarrollo necesitan tecnologÃƒÂ­as que sean abiertas, configurables y que permitan nuevos modelos de negocio. \r\n\r\nNuestra solucion a los retos que se enfrentan en el desarrollo de software es la familia de productos IBM Rational.  IBM Rational ofrece multiples productos para todas las fases del ciclo de desarrollo de software desde definir los requerimientos, pasando por analisis, diseÃƒÂ±o, codificacion, pruebas y mantenimiento, esta plataforma permite trasparencia en tiempo real, colaboraciÃƒÂ³n entre los equipos, permite la automatizaciÃƒÂ³n de las actividades de trabajo y provee el correcto control sobre los procesos de desarrollo. En las soluciones existentes en esta innovadora plataforma podemos manejar y definir los requerimientos usando Rational Requirements Composer, podemos tener de una manera centralizada nuestros planes de prueba y actividades que nos permitan asegurar la calidad de el software usando Rational Quality Manager y por ultimo tenemos un eficaz control de cÃƒÂ³digo, manejo de defectos y generaciÃƒÂ³n de productos todo integrado en Rational Team Concert.  Con estas herramientas los equipos pueden medir la salud actual de proyecto en tiempo real, automatizar buenas practicas, crear planes de pruebas, controlar el flujo de trabajo, tener reportes de mÃƒÂ©tricas y sobre todo unificar equipos distribuidos de desarrollo usando esta gama de aplicaciones. \r\n\r\nDescubriremos como nuestras herramientas son usadas en el una ambiente real, tomando varios roles de un equipo de desarrollo de software, aprenderemos el valor en el negocio de estas herramientas, como comparten informaciÃƒÂ³n, como colaboran entre ellas en el ambiente de trabajo cotidiano de una organizaciÃƒÂ³n dedicada al desarrollo de software y como estas ayudan a las organizaciones a entregar mejores productos de manera mas rÃƒÂ¡pida. \r\n',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(32,1,'Desarrollo de Aplicaciones con Javascript y Mootools','Desarrollo de Aplicaciones con Javascript y Mootools','Aprender a desarrollar aplicaciones web y de escritorio utilizando javascript y la biblioteca Mootools.\r\n\r\nRequisitos:\r\n\r\n- Conocimiento BÃƒÂ¡sico de Javascript (sintaxis, convenciones)\r\n- Conceptos bÃƒÂ¡sicos de CSS\r\n- Conceptos de desarrollo Web (Modelo cliente servidor, despliegue)\r\n- Manejo de herramientas de desarrollo (FTP, IDE)',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(33,1,'ProgramaciÃƒÂ³n de Microcontroladores con C','ProgramaciÃƒÂ³n de Microcontroladores con C','Este taller presenta una introducciÃƒÂ³n al panorama actual tecnolÃƒÂ³gico en referencia a los microcontroladores; arquitecturas, aplicaciones, modos de programaciÃƒÂ³n, etc. La parte practica se enfoca en la programaciÃƒÂ³n de microcontroladores de 8 bits utilizando el lenguaje de programaciÃƒÂ³n C (brevemente se presentan otras opciones de programaciÃƒÂ³n). Se utilizaran microcontroladores y herramientas de Freescale.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(34,1,'CakePHP BÃƒÂ¡sico','CakePHP BÃƒÂ¡sico','Una introducciÃƒÂ³n a Cake donde mostraremos como en 3 horas serÃƒÂ¡n capaces de experimentar toda la magia de CakePHP.\r\n\r\nImplementaran Javascript, CSS, Bases de Datos.\r\n\r\nEl proyecto sera una pagina personal que implementara que perimitira la entrada de blogs, comentarios en las entradas, parsing de noticias asi como rss y fotogalerias.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(35,1,'CakePHP Avanzado','CakePHP Avanzado','DemostraciÃƒÂ³n de como las nuevas tecnologias Web ayudan en el desarrollo de Sistemas Web o proyectos en General, ofreciendo reducciÃƒÂ³n de costos y un mayor performance en los proyectos.',1,'2010-03-14 15:48:19','2010-03-14 15:48:19',1,0),(1,1,'Natural User Interfaces: A New Generation of Human-Computer ','Natural User Interfaces: A New Generation of Human-Computer Interaction.','Natural User interface (NUI) es un tÃƒÂ©rmino nuevo utilizado por diseÃƒÂ±adores y desarrolladores para referirse a las interfaces de usuario que llegan a ser imperceptibles y no invasivas para el usuario. La palabra Ã¢â‚¬Å“naturalÃ¢â‚¬Â se opone al concepto \"artificial\" empleado para describir los dispositivos cuya operaciÃƒÂ³n debe ser aprendida y que requiere de una adaptaciÃƒÂ³n por parte del usuario (como el mouse, el teclado y los controles tradicionales para videojuegos con botones y palancas). Una NUI permite al usuario realizar sonidos, movimientos, gestos o pensamientos que le son inherentes y pone del lado de la computadora la responsabilidad de entender esos sonidos, movimientos, gestos o pensamientos como instrucciones que deberÃƒÂ¡ realizar. En el mundo de las interfaces naturales no existen teclados ni mouse,  existen tecnologÃƒÂ­as emergentes como:\r\n\r\na)	Brain Computer Interfaces (BCI): Con las que la computadora entiende lo que tÃƒÂº piensas. Ã‚Â¡SÃƒÂ­! Ã‚Â¡TelepatÃƒÂ­a Humano - computadora! Hay quien ya habla del Web 5.0 como el Web telepÃƒÂ¡tico. Ã‚Â¿complicado? Ã‚Â¿alejado? Ã‚Â¿una historia de cuento de hadas? Ã‚Â¡No!, con $300 dÃƒÂ³lares puedes obtener el hardware y ademÃƒÂ¡s existe software libre para comenzar a trabajar.\r\n\r\nb)	Reconocimiento de emociones. Ã‚Â¿has hecho gestos estando frente a tu computadora? Ã‚Â¿sonreÃƒÂ­r? o poner cara de Ã¢â‚¬ÂÃ‚Â¿esto quÃƒÂ© es?Ã¢â‚¬Â, Ã‚Â¿Sabes que el rostro humano es capaz de hacer sÃƒÂ³lo 48 diferentes expresiones? Y que la expresiÃƒÂ³n en tu rostro, Ã‚Â¡refleja tu estado de ÃƒÂ¡nimo! Tu prÃƒÂ³xima lap-top podrÃƒÂ­a saber si leer este texto te estÃƒÂ¡ interesando, haciendo reÃƒÂ­r o si te estÃƒÂ¡s durmiendo, y podrÃƒÂ­a reaccionar de acuerdo a tus emociones.\r\n\r\nc)	ComunicaciÃƒÂ³n no verbal. Gran parte de la comunicaciÃƒÂ³n humana no se da con palabras. Por ejemplo: Ã‚Â¿sabes quÃƒÂ© es, o mejor aÃƒÂºn, cÃƒÂ³mo funciona Microsoft Project Natal?  Ã‚Â¡Fundamentalmente es tecnologÃƒÂ­a para captura de movimientos!\r\n\r\nDurante la charla espero compartir contigo demostraciones y material (ligas, referencias, software) para que despuÃƒÂ©s puedas poner en prÃƒÂ¡ctica lo que en esta sesiÃƒÂ³n veamos.\r\n',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(2,1,'RIAvolution','RIAvolution','Estamos en tiempos clave para la definiciÃƒÂ³n del futuro de las aplicaciones de internet. Y esta conferencia esta enfocada en dar a conocer las principales caraterÃƒÂ­sticas de las aplicaciones RIA, las cuales juegan un papel fundamental en esta revoluciÃƒÂ³n de  interfaces de usuario para interactuar con la plataforma web.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(3,1,'Redes Sociales: MÃƒÂ¡s allÃƒÂ¡ del Facebook y el Twitter','Redes Sociales: MÃƒÂ¡s allÃƒÂ¡ del Facebook y el Twitter','Panorama actual de las redes sociales, su uso y cÃƒÂ³mo aprovecharlas al mÃƒÂ¡ximo sin detenernos en las dos mÃƒÂ¡s populares actualmente. QuÃƒÂ© es el Social Media y por quÃƒÂ© nos interesa conocerlo. Unete a la conversaciÃƒÂ³n.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(4,1,'TecnologÃƒÂ­a - Empresa - Individuos','TecnologÃƒÂ­a - Empresa - Individuos','La tecnologÃƒÂ­a como tal ha evolucionado vertiginosamente. Sin embargo, el beneficio en las compaÃƒÂ±ÃƒÂ­as no es proporcional a la velocidad de los avances y mucho menos a la capacidad de asimilaciÃƒÂ³n de los individuos. Es importante identificar las causas, las cuales pueden estar ligadas a la esencia humana. Ãƒâ€°ste es el nuevo reto para la gente de TecnologÃƒÂ­as de InformaciÃƒÂ³n.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(5,1,'AtracciÃƒÂ³n de usuarios con y SIN el uso de las redes socia','AtracciÃƒÂ³n de usuarios con y SIN el uso de las redes sociales','<!--break-->Una charla en la que se hablarÃƒÂ¡ somÃƒÂ©ramente de las formas que existen para atraer usuarios (y posibles patrocinios) hacia nuestros proyectos usando las nuevas redes sociales, pero sobre todo mÃƒÂ©todos que despues de estas ÃƒÂºltimas, se han descuidado un poco.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(6,1,'Presente y futuro en las nuevas tecnologÃƒÂ­as: tendencias, ','Presente y futuro en las nuevas tecnologÃƒÂ­as: tendencias, medios sociales y metaversos.','En esta charla tendremos una aproximaciÃƒÂ³n a la actualidad de las llamadas nuevas tecnologÃƒÂ­as, sus actores y componentes, sus implicaciones sociales y las tendencias que se perciben para un futuro cercano.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(7,1,'ConstrucciÃƒÂ³n del ser a travÃƒÂ©s de los videojuegos: una ','ConstrucciÃƒÂ³n del ser a travÃƒÂ©s de los videojuegos: una aproximaciÃƒÂ³n desde la fenomenologÃƒÂ­a','El ser humano se construye a sÃƒÂ­ mismo constantemente a travÃƒÂ©s de su relaciÃƒÂ³n con la tecnologÃƒÂ­a. La presente ponencia pretende arrojar luz sobre algunos de los efectos de los videojuegos en la construcciÃƒÂ³n de la identidad del jugador, asÃƒÂ­ como de sus procesos de socializaciÃƒÂ³n. Este anÃƒÂ¡lisis fenomenolÃƒÂ³gico considerarÃƒÂ¡ las relaciones en las cuales el individuo interactÃƒÂºa con la tecnologÃƒÂ­a, en un rango que va del casi-yo al casi-otro.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0),(8,1,'Un panorama del Social Media en MÃƒÂ©xico, 2010 un aÃƒÂ±o de','Un panorama del Social Media en MÃƒÂ©xico, 2010 un aÃƒÂ±o de oportunidades...','En el 2009 fuimos testigos de un inusitado auge de Redes Sociales en nuestro paÃƒÂ­s, servicios como Facebook y Twitter de pronto brincaron de la red a ser noticia, a veces no de manera positiva, pero eso sirviÃƒÂ³ para que miles de personas de pronto se interesaran por estar en la red. De esta manera se genero un aumento exponencial del nÃƒÂºmero de usuarios que utilizan estos servicios, conviertiÃƒÂ©ndose en objetivo de agencias, medios, marcas, empresas, etc.\r\n\r\nÃ‚Â¿Es el Social Media para todas las empresas? Ã‚Â¿Se puede vivir del bloging y las redes sociales? Ã‚Â¿CuÃƒÂ¡les son los servicios mÃƒÂ¡s utilizados en MÃƒÂ©xico? Esa y otras preguntas trataremos de responderlas en esta charla, ademÃƒÂ¡s de repasar el panorama de los Social Media en MÃƒÂ©xico, sus perspectivas y ÃƒÂ¡reas de oportunidad para este aÃƒÂ±o.',3,'2010-03-14 16:04:41','2010-03-14 16:04:41',1,0);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activities_users`
--

DROP TABLE IF EXISTS `activities_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities_users` (
  `activity_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`activity_id`,`user_id`),
  KEY `activity_id` (`activity_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities_users`
--

LOCK TABLES `activities_users` WRITE;
/*!40000 ALTER TABLE `activities_users` DISABLE KEYS */;
INSERT INTO `activities_users` VALUES (1,4),(2,9),(2,10),(3,31),(3,32),(4,30),(5,33),(6,35),(7,34),(8,1),(8,2),(8,36),(9,6),(10,7),(11,8),(12,9),(13,11),(14,12),(15,4),(16,5),(17,10),(18,13),(19,14),(20,19),(20,20),(21,21),(22,23),(23,15),(24,16),(25,17),(26,16),(27,18),(27,22),(28,4),(29,25),(30,25),(31,26),(32,27),(33,28),(34,24),(35,24),(35,29);
/*!40000 ALTER TABLE `activities_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `areas`
--

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,'Finances','Signup and payment management',0,1),(2,'Activities','Workshops, keynotes, conferences, etc',0,1),(3,'Image','Design and printing',0,1),(4,'Communication','Link between the committee and the participants',0,1),(5,'Users','Users\' management',0,1),(6,'Logistics','Services offered by the event',0,1),(7,'Settings','Site configuration and options',0,1);
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authake_groups`
--

DROP TABLE IF EXISTS `authake_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authake_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authake_groups`
--

LOCK TABLES `authake_groups` WRITE;
/*!40000 ALTER TABLE `authake_groups` DISABLE KEYS */;
INSERT INTO `authake_groups` VALUES (1,'Administrators'),(3,'Other test group'),(2,'User & group managers'),(4,'Everybody');
/*!40000 ALTER TABLE `authake_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authake_groups_users`
--

DROP TABLE IF EXISTS `authake_groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authake_groups_users` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authake_groups_users`
--

LOCK TABLES `authake_groups_users` WRITE;
/*!40000 ALTER TABLE `authake_groups_users` DISABLE KEYS */;
INSERT INTO `authake_groups_users` VALUES (1,2),(1,3),(2,2),(4,3),(1,1),(35,4);
/*!40000 ALTER TABLE `authake_groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authake_profiles`
--

DROP TABLE IF EXISTS `authake_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authake_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `team_id` int(11) NOT NULL,
  `birthdate` date NOT NULL,
  `organization_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authake_profiles`
--

LOCK TABLES `authake_profiles` WRITE;
/*!40000 ALTER TABLE `authake_profiles` DISABLE KEYS */;
INSERT INTO `authake_profiles` VALUES (1,1,'Francisco','Avila','elfrank',0,'1988-06-01',1),(2,2,'Test 1','Test 1','Test 1',3,'1988-06-01',1),(3,3,'Test 2','Test 2','Test 2',6,'1988-06-01',1),(4,4,'Test 3','Test 3','Test 3',10,'1988-06-01',1),(5,35,'test4','test4','test4',0,'1988-06-01',1),(6,37,'Carlos','Lopez','Carlos',0,'1988-06-01',1),(7,38,'Juan','Perez','Juan',6,'1988-06-01',1),(8,39,'Maria','Rodriguez','Juan',6,'1988-06-01',1),(9,40,'Mario','Ramirez','Mario',6,'1988-06-01',1),(10,41,'Alberto','Santana','Beto',6,'1988-06-01',1);
/*!40000 ALTER TABLE `authake_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authake_rules`
--

DROP TABLE IF EXISTS `authake_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authake_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) CHARACTER SET latin1 NOT NULL COMMENT 'Rule description',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order` int(10) unsigned DEFAULT NULL,
  `action` varchar(512) CHARACTER SET latin1 DEFAULT NULL,
  `permission` enum('Deny','Allow') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Deny',
  `forward` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authake_rules`
--

LOCK TABLES `authake_rules` WRITE;
/*!40000 ALTER TABLE `authake_rules` DISABLE KEYS */;
INSERT INTO `authake_rules` VALUES (1,'Allow everything for Administrators',1,999999,'*','Allow','',''),(2,'Allow anybody to see the home page, the error page, to register, to log in, see profile and log out',1,200,'/ or /authake/user/* or /activities','Allow','',''),(3,'(example) Allow anybody to view the rules list',1,700,'/authake/rules/index','Deny','',''),(4,'Deny everything for everybody by default (allow to have allow by default then deny)',0,0,'*','Deny','','Access denied!'),(5,'Allow \"user & group managers\" to edit users, groups and view rules',2,800,'/authake(/index)? or /authake/*/index/tableonly or /authake/users/(index|add/?|edit/[0-9]+|view/[0-9]+|delete/[0-9]+) or /authake/groups/(index|add/?|edit/[0-9]+|view/[0-9]+|delete/[0-9]+) or /authake/rules/(index|view/[0-9]+)','Allow','',''),(6,'Display a message for denied admin page',0,100,'/authake(/index)? or /authake/users* or /authake/groups* or /authake/rules*','Deny','','You are not allowed to access the administration page!');
/*!40000 ALTER TABLE `authake_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authake_users`
--

DROP TABLE IF EXISTS `authake_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authake_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(128) NOT NULL,
  `emailcheckcode` varchar(128) NOT NULL,
  `passwordchangecode` varchar(128) NOT NULL,
  `disable` tinyint(1) NOT NULL COMMENT 'Disable/enable account',
  `expire_account` date NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authake_users`
--

LOCK TABLES `authake_users` WRITE;
/*!40000 ALTER TABLE `authake_users` DISABLE KEYS */;
INSERT INTO `authake_users` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','root','','',0,'0000-00-00','0000-00-00 00:00:00','2008-02-12 12:19:31'),(2,'acluser','5d35a4a2209c621b2896db016388db31','acluser@example.com','','',0,'2030-01-01','2008-01-26 19:08:03','2008-02-13 12:22:48'),(4,'otheruser','95e6a007d09887c5681d9b758ad644dd','otheruser@example.com','','',1,'2028-01-01','2008-01-30 23:40:03','2008-02-13 08:55:03'),(3,'simpleuser','96c8cd0d4d88181c5f9836457c0d9b1c','simpleuser@example.com','','',0,'2008-02-16','2008-01-31 16:47:09','2008-02-12 12:19:22'),(35,'test4','86985e105f79b95d6bc918fb45ec7727','test4@gmail.com','','',0,'0000-00-00','2010-04-18 15:22:53','2010-04-18 15:22:53'),(36,'carlos','dc599a9972fde3045dab59dbd1ae170b','carlos.lopez.garces@gmail.com','','',0,'0000-00-00','2010-04-18 18:41:35','2010-04-18 18:41:35'),(37,'clopez','21232f297a57a5a743894a0e4a801fc3','clopez@mail.com','','',0,'0000-00-00','2010-04-30 00:28:00','2010-04-30 00:28:00'),(38,'jperez','21232f297a57a5a743894a0e4a801fc3','jperez@mail.com','','',0,'0000-00-00','2010-04-30 00:29:10','2010-04-30 00:29:10'),(39,'mrodriguez','21232f297a57a5a743894a0e4a801fc3','mrodriguez@mail.com','','',0,'0000-00-00','2010-04-30 00:29:28','2010-04-30 00:29:28'),(40,'mramirez','21232f297a57a5a743894a0e4a801fc3','mramirez@mail.com','','',0,'0000-00-00','2010-04-30 00:29:47','2010-04-30 00:29:47'),(41,'asantana','21232f297a57a5a743894a0e4a801fc3','asantana@mail.com','','',0,'0000-00-00','2010-04-30 00:30:02','2010-04-30 00:30:02');
/*!40000 ALTER TABLE `authake_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codes`
--

DROP TABLE IF EXISTS `codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) unsigned NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `code` varchar(20) CHARACTER SET armscii8 NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `used` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `use_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codes`
--

LOCK TABLES `codes` WRITE;
/*!40000 ALTER TABLE `codes` DISABLE KEYS */;
INSERT INTO `codes` VALUES (1,2,NULL,'1','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(2,2,NULL,'2','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(3,2,NULL,'3','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(4,2,NULL,'4','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(5,2,NULL,'5','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(6,2,NULL,'6','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(7,2,NULL,'7','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(8,2,NULL,'8','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(9,2,NULL,'9','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(10,2,NULL,'10','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(11,2,NULL,'11','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(12,2,NULL,'12','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(13,2,NULL,'13','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(14,2,NULL,'14','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(15,2,NULL,'15','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(16,2,NULL,'16','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(17,2,NULL,'17','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(18,2,NULL,'18','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(19,2,NULL,'19','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(20,2,NULL,'20','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(21,2,NULL,'21','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(22,2,NULL,'22','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(23,2,NULL,'23','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(24,2,NULL,'24','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(25,2,NULL,'25','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(26,2,NULL,'26','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(27,2,NULL,'27','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(28,2,NULL,'28','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(29,2,NULL,'29','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(30,2,NULL,'30','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(31,2,NULL,'31','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(32,2,NULL,'32','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(33,2,NULL,'33','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(34,2,NULL,'34','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(35,2,NULL,'35','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(36,2,NULL,'36','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(37,2,NULL,'37','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(38,2,NULL,'38','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(39,2,NULL,'39','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(40,2,NULL,'40','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(41,2,NULL,'41','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(42,2,NULL,'42','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(43,2,NULL,'43','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(44,2,NULL,'44','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(45,2,NULL,'45','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(46,2,NULL,'46','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(47,2,NULL,'47','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(48,2,NULL,'48','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(49,2,NULL,'49','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(50,2,NULL,'50','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(51,2,NULL,'51','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(52,2,NULL,'52','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(53,2,NULL,'53','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(54,2,NULL,'54','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(55,2,NULL,'55','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(56,2,NULL,'56','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(57,2,NULL,'57','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(58,2,NULL,'58','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(59,2,NULL,'59','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(60,2,NULL,'60','599.00','2010-03-16 04:22:12','2010-03-16 04:22:12',0,'no','0000-00-00 00:00:00'),(61,1,NULL,'61','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(62,1,NULL,'62','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(63,1,NULL,'63','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(64,1,NULL,'64','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(65,1,NULL,'65','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(66,1,NULL,'66','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(67,1,NULL,'67','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(68,1,NULL,'68','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(69,1,NULL,'69','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(70,1,NULL,'70','299.00','2010-03-16 04:23:21','2010-03-16 04:23:21',0,'no','0000-00-00 00:00:00'),(71,1,NULL,'71','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(72,1,NULL,'72','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(73,1,NULL,'73','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(74,1,NULL,'74','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(75,1,NULL,'75','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(76,1,NULL,'76','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(77,1,NULL,'77','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(78,1,NULL,'78','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(79,1,NULL,'79','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(80,1,NULL,'80','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(81,1,NULL,'81','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(82,1,NULL,'82','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(83,1,NULL,'83','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(84,1,NULL,'84','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(85,1,NULL,'85','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(86,1,NULL,'86','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(87,1,NULL,'87','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(88,1,NULL,'88','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(89,1,NULL,'89','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00'),(90,1,NULL,'90','599.00','2010-03-16 04:24:25','2010-03-16 04:24:25',0,'no','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contenttypes`
--

DROP TABLE IF EXISTS `contenttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contenttypes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contenttypes`
--

LOCK TABLES `contenttypes` WRITE;
/*!40000 ALTER TABLE `contenttypes` DISABLE KEYS */;
INSERT INTO `contenttypes` VALUES (1,'Taller','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(2,'Conferencia','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(3,'Charla','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(4,'Evento Social','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(5,'Registro','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(6,'Break','','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(7,'Comida','','0000-00-00 00:00:00','0000-00-00 00:00:00',0);
/*!40000 ALTER TABLE `contenttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET armscii8 NOT NULL,
  `description` text CHARACTER SET armscii8 NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'50% discount','A discount of 50% off the price of the ticket.','2010-03-16 04:09:25','2010-05-02 17:37:56',0),(2,'Free Pass','A discount of 100% off the price of the ticket.','2010-03-16 04:09:43','2010-05-02 17:37:47',0);
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `short_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `long_name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `slogan` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `place` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'10Ã‹Å¡ CISC','10Ã‹Å¡ Congreso Internacional de Sistemas Computacionales','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','Tu Cita con el Futuro','ITESM Campus Guadalajara','2010-03-18','2010-03-20','2010-03-14 08:40:15','2010-05-02 14:58:23',1,0);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberships`
--

DROP TABLE IF EXISTS `memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(10) unsigned NOT NULL,
  `team_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberships`
--

LOCK TABLES `memberships` WRITE;
/*!40000 ALTER TABLE `memberships` DISABLE KEYS */;
INSERT INTO `memberships` VALUES (3,4,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,5,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,6,2,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,6,3,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,7,3,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,8,3,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,9,3,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,10,4,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `area_id` int(11) NOT NULL,
  `url` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Activities','Activities Management.',2,'activities',1,0),(2,'Users','Users Management.',5,'users',1,0),(3,'Groups','Groups Management.',5,'groups',1,0),(4,'Rules','Rules Management.',5,'rules',1,0),(5,'Areas','Areas Management.',6,'areas',1,0),(6,'Codes','Codes Management.',1,'codes',1,0),(7,'Content Types','Content Types Management.',2,'contenttypes',1,0),(8,'Coupons','Coupons Management.',1,'coupons',1,0),(9,'Event','Event Management.',6,'events',1,0),(10,'Menus','Menus Management.',7,'menus',1,0),(11,'Places','Places Management.',2,'places',1,0),(12,'Schedules','Schedules Management.',2,'schedules',1,0),(13,'States','States Management.',7,'states',1,0),(14,'Teams','Teams Management.',5,'teams',1,0),(15,'Profiles','Profiles Management.',5,'profiles',1,0),(16,'Packages','Package management.',1,'packages',1,0),(17,'Signups','Signup management.',1,'packages/signups',1,0),(18,'Users','Users Management.',5,'users',1,0);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'ITESM');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `qty` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (2,'Package A','Signup package A.','430.00',50,'2010-04-17 20:30:05','2010-05-01 14:37:23'),(3,'Package C','Signup package C.','790.00',20,'2010-04-17 20:30:58','2010-05-02 01:17:58'),(4,'Package D','Signup package D.','40.00',10,'2010-04-17 20:36:08','2010-05-02 01:18:04'),(6,'Package E','Signup package E.','410.00',5,'2010-04-17 20:38:18','2010-05-02 01:18:11'),(12,'Package H','Signup pack...','600.00',0,'2010-04-17 23:40:49',NULL),(13,'Package R','Signup package R.','40.00',12,'2010-04-18 19:15:23',NULL),(14,'Package Z','Signup package Z.','1000.00',22,'2010-04-21 04:06:46','2010-05-02 01:18:18');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_profiles`
--

DROP TABLE IF EXISTS `packages_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_profiles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `package_id` int(10) unsigned NOT NULL,
  `profile_id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_profiles`
--

LOCK TABLES `packages_profiles` WRITE;
/*!40000 ALTER TABLE `packages_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `places` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (1,'SalÃƒÂ³n 6104','','2010-03-14 19:21:51','2010-03-14 19:21:51',0),(2,'Laboratorio Mocap','','2010-03-14 19:21:51','2010-03-14 19:21:51',0),(3,'SalÃƒÂ³n Medicina','','2010-03-14 19:22:29','2010-03-14 19:22:29',0),(4,'SalÃƒÂ³n 4201','','2010-03-14 19:22:29','2010-03-14 19:22:29',0),(5,'Laboratorio Multimedios','','2010-03-14 19:23:17','2010-03-14 19:23:17',0),(6,'SalÃƒÂ³n 3301','','2010-03-14 19:23:17','2010-03-14 19:23:17',0),(7,'Auditorio 2','','2010-03-14 19:24:55','2010-03-14 19:24:55',0),(8,'SalÃƒÂ³n 1205','','2010-03-14 19:24:55','2010-03-14 19:24:55',0),(9,'SalÃƒÂ³n 1305','','2010-03-14 19:25:37','2010-03-14 19:25:37',0),(10,'SalÃƒÂ³n 3302','','2010-03-14 19:25:37','2010-03-14 19:25:37',0),(11,'SalÃƒÂ³n 6103','','2010-03-14 19:26:14','2010-03-14 19:26:14',0),(12,'SalÃƒÂ³n 2401','','2010-03-14 19:26:14','2010-03-14 19:26:14',0),(13,'IBM Guadalajara','','2010-03-14 19:26:56','2010-03-14 19:26:56',0),(14,'SalÃƒÂ³n 4103','','2010-03-14 19:26:56','2010-03-14 19:26:56',0),(15,'SalÃƒÂ³n 5101','','2010-03-14 19:27:29','2010-03-14 19:27:29',0),(16,'SalÃƒÂ³n 5202','','2010-03-14 19:27:29','2010-03-14 19:27:29',0),(17,'SalÃƒÂ³n 2409','','2010-03-14 19:28:14','2010-03-14 19:28:14',0),(18,'SalÃƒÂ³n 5201','','2010-03-14 19:28:14','2010-03-14 19:28:14',0),(19,'SalÃƒÂ³n 2402','','2010-03-14 19:29:02','2010-03-14 19:29:02',0),(20,'SalÃƒÂ³n 3307','','2010-03-14 19:29:02','2010-03-14 19:29:02',0),(21,'SalÃƒÂ³n 4103','','2010-03-14 19:29:35','2010-03-14 19:29:35',0),(22,'SalÃƒÂ³n 3307','','2010-03-14 19:29:35','2010-03-14 19:29:35',0),(23,'SalÃƒÂ³n 2301','','2010-03-14 19:52:47','2010-03-14 19:52:47',0),(24,'SalÃƒÂ³n 2405','','2010-03-14 19:52:47','2010-03-14 19:52:47',0),(25,'SalÃƒÂ³n 2103','','2010-03-14 19:53:04','2010-03-14 19:53:04',0);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) unsigned NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `place_id` int(11) NOT NULL,
  `slots` int(11) unsigned NOT NULL,
  `current_slots` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,9,'2010-03-18 16:00:00','2010-03-18 19:15:00',12,32,0,1,'2010-03-14 16:32:44','2010-03-16 02:52:05',0),(2,9,'2010-03-19 16:00:00','2010-03-19 19:15:00',12,32,0,1,'2010-03-14 16:32:44','2010-03-16 04:04:37',0),(3,10,'2010-03-18 16:00:00','2010-03-18 19:15:00',5,27,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(6,11,'2010-03-19 16:00:00','2010-03-19 19:15:00',10,24,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(8,12,'2010-03-19 16:00:00','2010-03-19 19:15:00',6,20,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(9,13,'2010-03-18 16:00:00','2010-03-18 19:15:00',11,14,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(10,13,'2010-03-19 16:00:00','2010-03-19 19:15:00',11,14,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(12,14,'2010-03-19 16:00:00','2010-03-19 19:15:00',15,30,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(14,15,'2010-03-19 16:00:00','2010-03-19 19:15:00',2,15,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(15,16,'2010-03-18 16:00:00','2010-03-18 19:15:00',3,15,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(17,17,'2010-03-18 16:00:00','2010-03-18 19:15:00',4,20,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(20,18,'2010-03-19 16:00:00','2010-03-19 19:15:00',5,12,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(21,19,'2010-03-18 16:00:00','2010-03-18 19:15:00',8,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(22,19,'2010-03-19 16:00:00','2010-03-19 19:15:00',9,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(23,20,'2010-03-18 16:00:00','2010-03-18 19:15:00',7,200,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(24,20,'2010-03-19 16:00:00','2010-03-19 19:15:00',7,200,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(26,21,'2010-03-19 16:00:00','2010-03-19 19:15:00',14,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(27,22,'2010-03-18 16:00:00','2010-03-18 19:15:00',21,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(29,23,'2010-03-18 16:00:00','2010-03-18 19:15:00',1,26,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(30,23,'2010-03-19 16:00:00','2010-03-19 19:15:00',1,26,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(31,24,'2010-03-18 16:00:00','2010-03-18 19:15:00',18,24,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(33,25,'2010-03-18 16:00:00','2010-03-18 19:15:00',17,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(34,25,'2010-03-19 16:00:00','2010-03-19 19:15:00',17,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(36,26,'2010-03-19 16:00:00','2010-03-19 19:15:00',18,24,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(37,27,'2010-03-18 17:00:00','2010-03-18 19:15:00',13,50,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(38,27,'2010-03-19 17:00:00','2010-03-19 19:15:00',13,50,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(39,28,'2010-03-18 16:00:00','2010-03-18 19:15:00',22,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(41,29,'2010-03-18 16:00:00','2010-03-18 19:15:00',16,24,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(44,30,'2010-03-19 16:00:00','2010-03-19 19:15:00',16,24,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(45,31,'2010-03-18 16:00:00','2010-03-18 19:15:00',23,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(46,31,'2010-03-19 16:00:00','2010-03-19 19:15:00',23,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(47,32,'2010-03-18 16:00:00','2010-03-18 19:15:00',19,32,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(48,32,'2010-03-19 16:00:00','2010-03-19 19:15:00',19,32,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(49,33,'2010-03-18 16:00:00','2010-03-18 19:15:00',25,14,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(50,33,'2010-03-19 16:00:00','2010-03-19 19:15:00',25,14,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(51,34,'2010-03-18 16:00:00','2010-03-18 19:15:00',15,30,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(54,35,'2010-03-19 16:00:00','2010-03-19 19:15:00',22,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(55,1,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(57,2,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(60,3,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,200,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(62,4,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(64,5,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,200,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(66,6,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,50,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(67,7,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,28,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0),(69,8,'2010-03-20 10:45:00','2010-03-20 12:15:00',1,80,0,1,'2010-03-14 16:32:44','2010-03-14 16:32:44',0);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules_users`
--

DROP TABLE IF EXISTS `schedules_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules_users` (
  `schedule_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`schedule_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules_users`
--

LOCK TABLES `schedules_users` WRITE;
/*!40000 ALTER TABLE `schedules_users` DISABLE KEYS */;
INSERT INTO `schedules_users` VALUES (1,1),(1,2),(1,4);
/*!40000 ALTER TABLE `schedules_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signups`
--

DROP TABLE IF EXISTS `signups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(10) unsigned NOT NULL,
  `package_id` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `paid` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `user_id` (`profile_id`,`package_id`),
  KEY `user_package` (`profile_id`,`package_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signups`
--

LOCK TABLES `signups` WRITE;
/*!40000 ALTER TABLE `signups` DISABLE KEYS */;
INSERT INTO `signups` VALUES (35,6,2,'2010-04-30 00:53:09','2010-04-30 00:53:09','no'),(36,7,2,'2010-04-30 00:53:12','2010-04-30 00:53:12','no'),(37,8,2,'2010-04-30 00:53:15','2010-04-30 00:53:15','no'),(38,9,2,'2010-04-30 00:53:18','2010-04-30 00:53:18','no'),(39,10,2,'2010-04-30 00:53:22','2010-04-30 00:53:22','no');
/*!40000 ALTER TABLE `signups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Aguascalientes'),(2,'Baja California'),(3,'Baja California Sur'),(4,'Campeche'),(5,'Chiapas'),(6,'Chihuahua'),(7,'Coahuila'),(8,'Colima'),(9,'Distrito Federal'),(10,'Durango'),(11,'Estado de MÃƒÂ©xico'),(12,'Guanajuato'),(13,'Guerrero'),(14,'Hidalgo'),(15,'Jalisco'),(16,'MichoacÃƒÂ¡n'),(17,'Morelos'),(18,'Nayarit'),(19,'Nuevo LeÃƒÂ³n'),(20,'Oaxaca'),(21,'Puebla'),(22,'QuerÃƒÂ©taro'),(23,'Quintana Roo'),(24,'San Luis PotosÃƒÂ­'),(25,'Sinaloa'),(26,'Sonora'),(27,'Tabasco'),(28,'Tamaulipas'),(29,'Tlaxcala'),(30,'Veracruz'),(31,'YucatÃƒÂ¡n'),(32,'Zacatecas');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,1,'01 Nogales','2010-03-16 02:04:06','2010-03-16 04:18:02',0),(2,1,'02 Apan','2010-03-16 04:18:28','2010-03-16 04:18:28',0),(3,1,'03 Colima Vallejo','2010-03-16 04:18:42','2010-03-16 04:18:42',0),(4,1,'04 Celaya','2010-03-16 04:18:54','2010-03-16 04:18:54',0),(5,1,'05 Unisierra Jorge','2010-03-16 04:19:16','2010-03-16 04:19:16',0),(6,1,'06 Laguna','2010-03-16 04:19:27','2010-03-16 04:19:27',0),(7,1,'06B Toluca','2010-03-16 04:19:44','2010-03-16 04:19:44',0),(8,1,'07 Laguna','2010-03-16 04:19:58','2010-03-16 04:19:58',0),(9,1,'08 UTSOE','2010-03-16 04:20:13','2010-03-16 04:20:13',0),(10,1,'09 Cd. Cuah','2010-03-16 04:20:30','2010-03-16 04:20:30',0),(11,1,'10 Colima Rodolfo','2010-03-16 04:20:44','2010-03-16 04:20:44',0),(12,1,'12 Laguna Rodolfo','2010-03-16 04:20:59','2010-03-16 04:20:59',0),(13,1,'15 Tacambaro','2010-03-16 04:22:52','2010-03-16 04:22:52',0),(14,1,'16 Tepic Diana','2010-03-16 04:23:02','2010-03-16 04:23:02',0);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-05-02 20:14:32
