<?php
class ActivitiesController extends AppController {

	var $name = 'Activities';
	var $helpers = array('Authake.Htmlbis', 'Form', 'Time');
	var $uses = array('Activity', 'Contenttype', 'Event');
    var $paginate = array(
                        'limit' => 10,
                        'order' => array(
                                         'Activity.created' => 'asc'
                                        )
                       );

	function index($tableonly = false) {
		$this->Activity->recursive = 1;
        $this->set('activities', $this->paginate());
        $this->set('tableonly', $tableonly);
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Activity', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('activity', $this->Activity->read(null, $id));
	}
	
	function admin_index($tableonly = false) {
		$this->Activity->recursive = 1;
        $this->set('activities', $this->paginate());
        $this->set('tableonly', $tableonly);
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Activity', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('activity', $this->Activity->read(null, $id));
	}

	function admin_add() {
		$this->set('eventList', $this->Event->find('list', array('fields' => array('id','short_name'))));
		$this->set('contentTypeList', $this->Contenttype->find('list'));
		if (!empty($this->data)) {
			$this->Activity->create();
			if ($this->Activity->save($this->data)) {
				$this->Session->setFlash(__('The Activity has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Activity could not be saved. Please, try again.', true));
			}
		}
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Activity', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Activity->save($this->data)) {
				$this->Session->setFlash(__('The Activity has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Activity could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Activity->read(null, $id);
			$this->set('eventList', $this->Event->find('list', array('fields' => array('id','short_name'))));
			$this->set('contentTypeList', $this->Contenttype->find('list'));
		}
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Activity', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Activity->del($id)) {
			$this->Session->setFlash(__('Activity deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Activity could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>
