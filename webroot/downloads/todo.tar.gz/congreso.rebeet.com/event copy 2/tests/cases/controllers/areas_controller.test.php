<?php 
/* SVN FILE: $Id$ */
/* AreasController Test cases generated on: 2010-04-17 15:29:24 : 1271536164*/
App::import('Controller', 'Areas');

class TestAreas extends AreasController {
	var $autoRender = false;
}

class AreasControllerTest extends CakeTestCase {
	var $Areas = null;

	function startTest() {
		$this->Areas = new TestAreas();
		$this->Areas->constructClasses();
	}

	function testAreasControllerInstance() {
		$this->assertTrue(is_a($this->Areas, 'AreasController'));
	}

	function endTest() {
		unset($this->Areas);
	}
}
?>