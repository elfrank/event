<?php 
/* SVN FILE: $Id$ */
/* Team Test cases generated on: 2010-04-18 18:05:33 : 1271631933*/
App::import('Model', 'Team');

class TeamTestCase extends CakeTestCase {
	var $Team = null;
	var $fixtures = array('app.team', 'app.user');

	function startTest() {
		$this->Team =& ClassRegistry::init('Team');
	}

	function testTeamInstance() {
		$this->assertTrue(is_a($this->Team, 'Team'));
	}

	function testTeamFind() {
		$this->Team->recursive = -1;
		$results = $this->Team->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Team' => array(
			'id' => 1,
			'user_id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'created' => '2010-04-18 18:05:33',
			'modified' => '2010-04-18 18:05:33',
			'deleted' => 1
		));
		$this->assertEqual($results, $expected);
	}
}
?>