<?php 
/* SVN FILE: $Id$ */
/* Profile Fixture generated on: 2010-04-18 14:11:16 : 1271617876*/

class ProfileFixture extends CakeTestFixture {
	var $name = 'Profile';
	var $table = 'profiles';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'user_id' => array('type'=>'integer', 'null' => false, 'default' => NULL),
		'first_name' => array('type'=>'string', 'null' => false, 'default' => NULL, 'length' => 120),
		'last_name' => array('type'=>'string', 'null' => false, 'default' => NULL, 'length' => 150),
		'display_name' => array('type'=>'string', 'null' => false, 'default' => NULL, 'length' => 120),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'user_id' => 1,
		'first_name' => 'Lorem ipsum dolor sit amet',
		'last_name' => 'Lorem ipsum dolor sit amet',
		'display_name' => 'Lorem ipsum dolor sit amet'
	));
}
?>