<?php 
/* SVN FILE: $Id$ */
/* Team Fixture generated on: 2010-04-18 18:05:33 : 1271631933*/

class TeamFixture extends CakeTestFixture {
	var $name = 'Team';
	var $table = 'teams';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'user_id' => array('type'=>'integer', 'null' => false, 'default' => NULL),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL, 'length' => 60),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'deleted' => array('type'=>'boolean', 'null' => false, 'default' => '0'),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'user_id' => 1,
		'name' => 'Lorem ipsum dolor sit amet',
		'created' => '2010-04-18 18:05:33',
		'modified' => '2010-04-18 18:05:33',
		'deleted' => 1
	));
}
?>