<?php 
     class Tweet extends AppModel
     {
          var $name = 'Tweet';
          var $useTable = false;
     }
?> 