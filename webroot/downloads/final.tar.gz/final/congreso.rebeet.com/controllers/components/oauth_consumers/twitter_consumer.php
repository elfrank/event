<?php
class TwitterConsumer extends AbstractConsumer {
    public function __construct() {
        parent::__construct('RCTaSO4B3UhaRtDx0my5IA', 'rWHZpRmzrH0Zfe6SEPzkvuKbeAn6hTfYQ2weplC9E');
    }
}
?>