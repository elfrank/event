<?php

class OrganizationsController extends AppController
{
  var $name = 'Organizations';
}

?>
