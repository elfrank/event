<?php
class SchedulesController extends AppController {

	var $name = 'Schedules';
	var $helpers = array('Authake.Htmlbis', 'Form', 'Time');
	var $uses = array('Schedule', 'Activity', 'Place', 'User');
    var $paginate = array(
                        'limit' => 30,
                        'order' => array(
                                         'Schedule.created' => 'asc'
                                        )
                       );

	function index($data = null) {
		$this->Schedule->recursive = 1;
		$user_id = $this->Session->read('Authake.id');
		$workshops_18 = $this->Schedule->find('all', array('conditions' => array('Activity.contenttype_id' => 1, 'Schedule.start_date' => '2010-03-18 16:00:00')));
		
		$this->Schedule->bindModel(array('hasOne' => array('SchedulesUser')));
		$schedule = $this->Schedule->find('first', array('fields' => array('Schedule.*'),'conditions'=>array('SchedulesUser.user_id'=>$user_id)));
		$schedule_id = $schedule['Schedule']['id'];
		$this->set('id', $schedule_id);
		$this->set('workshops_18', $workshops_18);			
		
		if(!empty($this->data)) {
			debug($this->data);
			$this->Schedule->save(array( 
				'Schedule' => array( 
					'id' => $this->data['Schedule']['schedule_id'], 
				), 
				'User' => array( 
					'User' => array($user_id), 
				), 
			));		
			if($schedule_id != '') {
				echo "delete";
				$sql = "DELETE FROM schedules_users WHERE schedule_id={$schedule_id} AND user_id={$user_id}";  
		  	    $this->Schedule->query($sql);
			}	
			echo $schedule_id = $this->data['Schedule']['schedule_id'];
			$this->set('id', $schedule_id);
		}
		
		
					
	        
/*
	        $workshops_19 = $this->Schedule->find('all', array('conditions' => array('Activity.contenttype_id' => 1, 'Schedule.start_date' => '2010-03-19 16:00:00')));
	        $keynote = $this->Schedule->find('all', array('conditions' => array('Activity.contenttype_id' => 2)));
*/
	        
			
		
	}
	
	function __selectedWorkshop($event) {
		foreach($event as $w) {
			foreach($w['User'] as $user) {
				if($user['login'] == $this->Session->read('Authake.login')) {
					return $w;
				}
			}
		}
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Schedule', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('schedule', $this->Schedule->read(null, $id));
	}
	
	function admin_index($tableonly = false) {
		$this->Schedule->recursive = 1;
        $this->set('schedules', $this->paginate());
        $this->set('tableonly', $tableonly);
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Schedule', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('schedule', $this->Schedule->read(null, $id));
	}

	function admin_add() {
		$this->set('activityList', $this->Activity->find('list', array('fields' => array('id','short_name'))));
		$this->set('placeList', $this->Place->find('list', array('fields' => array('id','name'))));
		$this->set('userList', $this->User->find('list', array('fields' => array('id','login'))));
		if (!empty($this->data)) {
			$this->Schedule->create();
			if ($this->Schedule->save($this->data)) {
				$this->Session->setFlash(__('The Schedule has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Schedule could not be saved. Please, try again.', true));
			}
		}
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Schedule', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Schedule->save($this->data)) {
				$this->Session->setFlash(__('The Schedule has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Schedule could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->set('activityList', $this->Activity->find('list', array('fields' => array('id','short_name'))));
			$this->set('placeList', $this->Place->find('list', array('fields' => array('id','name'))));
			$this->set('userList', $this->User->find('list', array('fields' => array('id','login'))));
			$this->data = $this->Schedule->read(null, $id);
		}
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Schedule', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Schedule->del($id)) {
			$this->Session->setFlash(__('Schedule deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Schedule could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>