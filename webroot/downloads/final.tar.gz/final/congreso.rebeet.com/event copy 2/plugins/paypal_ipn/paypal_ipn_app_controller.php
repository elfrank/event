<?php
class PaypalIpnAppController extends AppController {
  
}
?>