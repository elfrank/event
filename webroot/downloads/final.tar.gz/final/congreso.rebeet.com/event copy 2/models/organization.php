<?php

class Organization extends AppModel
{
  var $name = 'Organization';
}

?>
