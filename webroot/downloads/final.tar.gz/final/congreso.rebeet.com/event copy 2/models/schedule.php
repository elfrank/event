<?php
class Schedule extends AppModel {

	var $name = 'Schedule';
	var $validate = array(
		'activity_id' => array('numeric'),
		'start_date' => array('date'),
		'end_date' => array('date'),
		'place_id' => array('numeric'),
		'slots' => array('numeric'),
		'current_slots' => array('numeric'),
		'status' => array('numeric'),
		'deleted' => array('numeric')
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Activity' => array(
			'className' => 'Activity',
			'foreignKey' => 'activity_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Place' => array(
			'className' => 'Place',
			'foreignKey' => 'place_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

	var $hasAndBelongsToMany = array(
		'User' => array(
			'className' => 'AuthakeUser',
			'joinTable' => 'schedules_users',
			'foreignKey' => 'schedule_id',
			'associationForeignKey' => 'user_id',
			'unique' => true,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
			'deleteQuery' => '',
			'insertQuery' => ''
		)
	);

}
?>