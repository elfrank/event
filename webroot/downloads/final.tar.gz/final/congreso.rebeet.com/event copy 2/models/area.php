<?php
class Area extends AppModel {

	var $name = 'Area';

}
?>