-- phpMyAdmin SQL Dump
-- version 2.11.9.3
-- http://www.phpmyadmin.net
--
-- Host: mysql.tecnologias-avanzadas.net
-- Generation Time: Nov 10, 2010 at 09:50 PM
-- Server version: 5.0.24
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ie_congreso`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) NOT NULL,
  `short_name` varchar(60) collate utf8_unicode_ci NOT NULL,
  `long_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `contenttype_id` int(30) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `published` tinyint(1) NOT NULL default '1',
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=58 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `event_id`, `short_name`, `long_name`, `description`, `contenttype_id`, `created`, `modified`, `published`, `deleted`) VALUES
(9, 1, 'Desarrollo en Android', 'Desarrollo en Android', '', 1, '2010-03-14 15:48:19', '2010-11-10 15:00:45', 1, 0),
(10, 1, 'Desarrollo para iPhone', 'Desarrollo para iPhone', 'En este taller se presenta el software developer kit para el iPhone, se proporciona la información necesaria para empezar a desarrollar software en esta plataforma, así como una demostración de su uso. Se asume que el participante tiene conocimiento de programación orientada a objetos y de programación en general.', 1, '2010-03-14 15:48:19', '2010-11-10 16:09:55', 1, 0),
(12, 1, 'Adobe Flex', 'Adobe Flex', 'Taller enfocado a diseñadores y/o desarrolladores que quieran conocer Flex para realizar aplicaciones RIA. Se enseñan los fundamentos de esta tecnologá para hacer layouts de aplicaciones y consumir datos externos.\r\n\r\nNivel: Básico (recomendado conocimientos de XML y programación básica)', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(13, 1, 'Asterisk', 'Asterisk', '', 1, '2010-03-14 15:48:19', '2010-04-28 20:13:54', 0, 0),
(14, 1, 'Drupal - Creando portales dinámicos', 'Drupal - Creando portales dinámicos', 'En el taller aprenderemos sobre Drupal, uno de los mejores manejadores de contenidos (CMS) que existen actualmente. Revisaremos el flujo de trabajo y como es que Drupal hace para manejar el contenido y agregarle funcionalidad a los sitios. ', 1, '2010-03-14 15:48:19', '2010-11-10 16:07:47', 1, 0),
(15, 1, 'MoCap: Motion Capture', 'MoCap: Motion Capture', 'Los conceptos captura de movimiento, seguimiento de movimiento, o simplemente mocap (por su nombre en inglés), son utilizados para describir el proceso de capturar movimientos y traducirlos a un modelo digital. En otras palabras capturar las acciones de actores humanos y utilizar esta información para animar modelos digitales de caracteres en dos o tres dimensiones a través de una computadora. Estos procesos comprenden desde movimientos corporales hasta movimientos tan finos como gestos con las manos, dedos e incluso expresiones faciales. Mocap es utilizado en la milicia, la industria del entretenimiento y los deportes, aplicaciones médicas y la industria cinematográfica. Entre otras cosas para:\r\n\r\n- Videojuegos. Los videojuegos usan con mucha frecuencia movimientos capturados para animar atletas, movimientos de artes marciales, y otras acciones que deban lucir como humanas (bailar, abrazar, caer, saltar, etc).\r\n- Películas. En esta industria se utiliza la captura de movimiento para crear creaturas completamente animadas por computadoras, como el caso de los personajes: Jar-Jar Binks, Gollum, La Momia, King-Kong y los Navi de la película Avatar. ? Realidad virtual. La captura de movimiento permite que los usuarios interactúen con contenidos digitales en tiempo real. Esto se utiliza en simuladores, exámenes de percepción visual y para realizar recorridos virtuales en ambiente tridimensionales.\r\n\r\nObjetivos\r\n\r\n1. Introducción a la captura de movimientos: ¿Cómo funciona?\r\n2. Ejemplificar los principios básicos que sustentan la tecnologá de captura de movimiento\r\n3. Sistemas de captura de movimiento en 3D para animación, rehabilitación, simulación y entrenamiento. Trabajaremos con el sistema de Mocap inaugurado el 29 de noviembre pasado en el ITESM campus Guadalajara. Uno de los pocos sistemas de Mocap disponibles en México al alcance de estudiantes universitarios.\r\n4. Desarrollo de ideas simples para videojuegos y animación.', 1, '2010-03-14 15:48:19', '2010-11-10 16:05:31', 1, 0),
(16, 1, 'Programación', 'Programación', '', 1, '2010-03-14 15:48:19', '2010-11-10 16:04:45', 1, 0),
(17, 1, 'Videojuegos en Adobe Flash', 'Videojuegos en Adobe Flash', 'Crear juegos en flash.', 1, '2010-03-14 15:48:19', '2010-11-10 16:08:08', 1, 0),
(18, 1, 'Final Cut Studio Pro', 'Final Cut Studio Pro', '', 1, '2010-03-14 15:48:19', '2010-11-10 16:08:58', 1, 0),
(19, 1, 'Administración', 'Administración', 'En el nuevo mundo de las TI, administración.', 1, '2010-03-14 15:48:19', '2010-11-10 16:09:18', 1, 0),
(20, 1, 'NVIDIA: C', 'NVIDIA: C', '', 1, '2010-03-14 15:48:19', '2010-11-10 16:09:32', 1, 0),
(21, 1, 'Modding Avanzado', 'Modding Avanzado', '', 1, '2010-03-14 15:48:19', '2010-04-28 20:14:00', 0, 0),
(22, 1, 'Modding Básico', 'Modding Básico', 'Taller en el cual se muestra el correcto acomodo de los cables, flujo de aire y sus repercusiones en el rendimiento del equipo.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(23, 1, 'Descripción de técnicas y métodos utili', 'Descripción de técnicas y métodos utili', 'La construcción de software para sistemas de aviónica requiere la aplicación de métodos de ingenierá que aseguren que el producto final, tanto el software mismo como el sistema completo, sea seguro. En muchas ocasiones incluso el software mismo provee de capacidades de seguridad (safety) al sistema que de otra manera no podrán ser construidos. En el taller se explicarán los principales métodos y técnicas utilizados y se realizarán ejercicios donde estos sean aplicados.', 1, '2010-03-14 15:48:19', '2010-05-04 03:43:17', 1, 0),
(24, 1, 'Scripting en Ruby', 'Scripting en Ruby', 'Temas: \r\n\r\n- Introducción a ruby\r\n- Ruby viniendo de Java\r\n- Numeros, Strings, Símbolos y Diccionarios\r\n- Ciclos, condiciones\r\n- Programación Orientada a Objetos (clases)\r\n- Métodos, parámetros\r\n- Herencia, Mixins y Módulos\r\n- Bloques e Iteradores\r\n- Clases abiertas\r\n\r\nDescripción: En este taller aprenderás a usar el lenguaje de programación Ruby. Ruby es un lenguaje de programación dinámico orientado a objetos que se enfoca en la simplicidad y productividad. Tiene una sintaxis elegante que es fácil de leer y mejor aún de escribir.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(25, 1, 'Cloud Computing y Software On-Demand', 'Cloud Computing y Software On-Demand', 'El concepto de Multi-Tenancy es uno de los elementos centrales de las aplicaciones Cloud Computing y Software On-Demand. Una arquitectura de aplicación Multi-Tenant es aquella donde todos los usuarios de la aplicación, independientemente de la organización (cliente) a la que pertenecen, comparten la misma instancia del código, de la base de datos y de la infraestructura. Esta arquitectura es lo que permite alcanzar las economás de escala que se traducen en costos competitivos para estos modelos de negocio. Adicionalmente, multi-tenancy abre la puerta al análisis de datos de uso de las aplicaciones de una manera que nunca antes habá sido posible para los proveedores de software. Esta charla les dará a los asistentes conocimientos adicionales a los alumnos de universidad y recién egresados la oportunidad  de explorar las nuevas tendencias en relación a la arquitectura de software.\r\n\r\nNivel del Taller: Intermedio en Programación y Arquitectura.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(26, 1, 'Ruby on Rails: Desarrollo ágil de Aplicacio', 'Ruby on Rails: Desarrollo ágil de Aplicaciones', 'Temas:\r\n\r\n- Patrón Modelo Vista Controlador\r\n- Migraciones\r\n- Controladores, Modelos, Vistas\r\n- Validaciones automáticas\r\n- Desarrollo de un recetario/blog/lista de TO-DOs\r\n\r\nDescripción: Rails es una plataforma de desarrollo web que facilita el desarrollo de aplicaciones usando bases de datos como almacenes de información. Utiliza el patrón MVC para dividir la presentación, los datos y el control de la aplicación. Aprenderás las bases de la plataforma desarrollando una aplicación que podrás utilizar en tu vida diaria.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(27, 1, 'Visita Campus Tecnológico de IBM', 'Visita Campus Tecnológico de IBM', ' Agenda: \r\n\r\n4.00pm - 5.00pm : Visita al GASC* y el GRIC* \r\n\r\n5.00pm - 6.00pm : Charla sobre Quality Management usando Rational Quality Manager por parte de Agueda Martinez \r\n\r\n6.00pm - 6.45pm : Charla sobre IBM Campus Guadalajara y Rational por parte del Ing. Arturo Jafet Rodríguez \r\n', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(28, 1, 'Programando con el iPhone SDK', 'Programando con el iPhone SDK', '<ul>\r\n <li>Aprende sobre la arquitectura de software del iPhone</li>\r\n <li>Aprende sobre herramientas de desarrollo del iPhone y el lenguaje de Programación Objective-C</li>\r\n <li>Framework de Aplicaciones del iPhone</li>\r\n <li>Diseño de interfaces y buenas prácticas en el desarrollo de Aplicaciones para el iPhone</li>\r\n <li>Localización, Aceleración, Orientación e Información del Sistema</li>\r\n <li>Fundamentos del iPhone para Desarrolladores Web</li>\r\n</ul>\r\n', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(29, 1, 'OpenMP: Una Introducción al cÃƒÆ’Ã‚', 'OpenMP: Una Introducción al cómputo paralelo', 'Hoy en dá, las computadoras personales es común que contengan 2 o más núcleos de procesamiento. Esto lleva capacidades de cómputo paralelo a las manos de todos los usuarios. Utilizando la herramienta OpenMP aprenderemos los conceptos básicos de cómputo paralelo y las ventajas de utilizar el procesamiento en más de un núcleo.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(30, 1, 'Cómputo Distribuido de Alto Rendimiento con', 'Cómputo Distribuido de Alto Rendimiento con MPI', 'La posibilidad de crear super computadoras a partir de equipos económicos ha hecho que la arquitectura de clúster se popularice. Nuevas arquitecturas requieren nuevas herramientas, y la interfaz de paso de mensajes (MPI) se encamina como la herramienta por excelencia para el cómputo de alto rendimiento. Durante el taller exploraremos dicha herramienta y cómo utilizarla para resolver problemas con altas necesidades de procesamiento.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(31, 1, 'IBM Rational Team Concert', 'IBM Rational Team Concert', 'La actual situación en la industria es que se ha comenzado a hacer uso de equipos distribuidos  y el tener total control sobre el desarrollo de software se esta haciendo mas difícil cada dá. Estamos viendo equipos que están interconectados en la organización con diferentes arquitecturas y esto se hace cada vez mas presente en las organizaciones que desarrollan software. El desarrollar nuevos productos es un nicho crítico en la operativa diaria como a su vez lo es la entrega en tiempo. Las organizaciones de desarrollo necesitan tecnologás que sean abiertas, configurables y que permitan nuevos modelos de negocio. \r\n\r\nNuestra solucion a los retos que se enfrentan en el desarrollo de software es la familia de productos IBM Rational.  IBM Rational ofrece multiples productos para todas las fases del ciclo de desarrollo de software desde definir los requerimientos, pasando por analisis, diseño, codificacion, pruebas y mantenimiento, esta plataforma permite trasparencia en tiempo real, colaboración entre los equipos, permite la automatización de las actividades de trabajo y provee el correcto control sobre los procesos de desarrollo. En las soluciones existentes en esta innovadora plataforma podemos manejar y definir los requerimientos usando Rational Requirements Composer, podemos tener de una manera centralizada nuestros planes de prueba y actividades que nos permitan asegurar la calidad de el software usando Rational Quality Manager y por ultimo tenemos un eficaz control de código, manejo de defectos y generación de productos todo integrado en Rational Team Concert.  Con estas herramientas los equipos pueden medir la salud actual de proyecto en tiempo real, automatizar buenas practicas, crear planes de pruebas, controlar el flujo de trabajo, tener reportes de métricas y sobre todo unificar equipos distribuidos de desarrollo usando esta gama de aplicaciones. \r\n\r\nDescubriremos como nuestras herramientas son usadas en el una ambiente real, tomando varios roles de un equipo de desarrollo de software, aprenderemos el valor en el negocio de estas herramientas, como comparten información, como colaboran entre ellas en el ambiente de trabajo cotidiano de una organización dedicada al desarrollo de software y como estas ayudan a las organizaciones a entregar mejores productos de manera mas rápida. \r\n', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(32, 1, 'Desarrollo de Aplicaciones con Javascript y Mootools', 'Desarrollo de Aplicaciones con Javascript y Mootools', 'Aprender a desarrollar aplicaciones web y de escritorio utilizando javascript y la biblioteca Mootools.\r\n\r\nRequisitos:\r\n\r\n- Conocimiento Básico de Javascript (sintaxis, convenciones)\r\n- Conceptos básicos de CSS\r\n- Conceptos de desarrollo Web (Modelo cliente servidor, despliegue)\r\n- Manejo de herramientas de desarrollo (FTP, IDE)', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(33, 1, 'Programación de Microcontroladores con C', 'Programación de Microcontroladores con C', 'Este taller presenta una introducción al panorama actual tecnológico en referencia a los microcontroladores; arquitecturas, aplicaciones, modos de programación, etc. La parte practica se enfoca en la programación de microcontroladores de 8 bits utilizando el lenguaje de programación C (brevemente se presentan otras opciones de programación). Se utilizaran microcontroladores y herramientas de Freescale.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(34, 1, 'CakePHP Básico', 'CakePHP Básico', 'Una introducción a Cake donde mostraremos como en 3 horas serán capaces de experimentar toda la magia de CakePHP.\r\n\r\nImplementaran Javascript, CSS, Bases de Datos.\r\n\r\nEl proyecto sera una pagina personal que implementara que perimitira la entrada de blogs, comentarios en las entradas, parsing de noticias asi como rss y fotogalerias.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(35, 1, 'CakePHP Avanzado', 'CakePHP Avanzado', 'Demostración de como las nuevas tecnologias Web ayudan en el desarrollo de Sistemas Web o proyectos en General, ofreciendo reducción de costos y un mayor performance en los proyectos.', 1, '2010-03-14 15:48:19', '2010-03-14 15:48:19', 1, 0),
(1, 1, 'Natural User Interfaces', 'Natural User Interfaces: A New Generation of Human-Computer Interaction.', 'Natural User interface (NUI) es un término nuevo utilizado por diseñadores y desarrolladores para referirse a las interfaces de usuario que llegan a ser imperceptibles y no invasivas para el usuario. La palabra ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œnaturalÃƒÂ¢Ã¢â€šÂ¬Ã‚Â se opone al concepto "artificial" empleado para describir los dispositivos cuya operación debe ser aprendida y que requiere de una adaptación por parte del usuario (como el mouse, el teclado y los controles tradicionales para videojuegos con botones y palancas). Una NUI permite al usuario realizar sonidos, movimientos, gestos o pensamientos que le son inherentes y pone del lado de la computadora la responsabilidad de entender esos sonidos, movimientos, gestos o pensamientos como instrucciones que deberá realizar. En el mundo de las interfaces naturales no existen teclados ni mouse,  existen tecnologás emergentes como:\r\n\r\na)	Brain Computer Interfaces (BCI): Con las que la computadora entiende lo que tú piensas. ¡Sí! ¡Telepatá Humano - computadora! Hay quien ya habla del Web 5.0 como el Web telepático. ¿complicado? ¿alejado? ¿una historia de cuento de hadas? ¡No!, con $300 dólares puedes obtener el hardware y además existe software libre para comenzar a trabajar.\r\n\r\nb)	Reconocimiento de emociones. ¿has hecho gestos estando frente a tu computadora? ¿sonreír? o poner cara de ¿esto qué es?, ¿Sabes que el rostro humano es capaz de hacer sólo 48 diferentes expresiones? Y que la expresión en tu rostro, ¡refleja tu estado de ánimo! Tu próxima lap-top podrá saber si leer este texto te está interesando, haciendo reír o si te estás durmiendo, y podrá reaccionar de acuerdo a tus emociones.\r\n\r\nc)	Comunicación no verbal. Gran parte de la comunicación humana no se da con palabras. Por ejemplo: ¿sabes qué es, o mejor aún, cómo funciona Microsoft Project Natal?  ¡Fundamentalmente es tecnologá para captura de movimientos!\r\n\r\nDurante la charla espero compartir contigo demostraciones y material (ligas, referencias, software) para que después puedas poner en práctica lo que en esta sesión veamos.\r\n', 3, '2010-03-14 16:04:41', '2010-05-04 03:43:47', 1, 0),
(2, 1, 'RIAvolution', 'RIAvolution', 'Estamos en tiempos clave para la definición del futuro de las aplicaciones de internet. Y esta conferencia esta enfocada en dar a conocer las principales caraterísticas de las aplicaciones RIA, las cuales juegan un papel fundamental en esta revolución de  interfaces de usuario para interactuar con la plataforma web.', 3, '2010-03-14 16:04:41', '2010-03-14 16:04:41', 1, 0),
(3, 1, 'Redes Sociales', 'Redes Sociales: Más allá del Facebook y el Twitter', 'Panorama actual de las redes sociales, su uso y cómo aprovecharlas al máximo sin detenernos en las dos más populares actualmente. Qué es el Social Media y por qué nos interesa conocerlo. Unete a la conversación.', 3, '2010-03-14 16:04:41', '2010-05-04 03:44:35', 1, 0),
(4, 1, 'Tecnologá - Empresa - Individuos', 'Tecnologá - Empresa - Individuos', 'La tecnologá como tal ha evolucionado vertiginosamente. Sin embargo, el beneficio en las compañás no es proporcional a la velocidad de los avances y mucho menos a la capacidad de asimilación de los individuos. Es importante identificar las causas, las cuales pueden estar ligadas a la esencia humana. ÃƒÆ’Ã¢â‚¬Â°ste es el nuevo reto para la gente de Tecnologás de Información.', 3, '2010-03-14 16:04:41', '2010-03-14 16:04:41', 1, 0),
(5, 1, 'Atracción de usuarios con y SIN el uso de l', 'Atracción de usuarios con y SIN el uso de las redes sociales', '<!--break-->Una charla en la que se hablará soméramente de las formas que existen para atraer usuarios (y posibles patrocinios) hacia nuestros proyectos usando las nuevas redes sociales, pero sobre todo métodos que despues de estas últimas, se han descuidado un poco.', 3, '2010-03-14 16:04:41', '2010-03-14 16:04:41', 1, 0),
(6, 1, 'Presente y futuro en las nuevas tecnologás', 'Presente y futuro en las nuevas tecnologás: tendencias, medios sociales y metaversos.', 'En esta charla tendremos una aproximación a la actualidad de las llamadas nuevas tecnologás, sus actores y componentes, sus implicaciones sociales y las tendencias que se perciben para un futuro cercano.', 3, '2010-03-14 16:04:41', '2010-03-14 16:04:41', 1, 0),
(7, 1, 'Construcción del ser a través de los videojuegos: una aproxi', 'Construcción del ser a través de los videojuegos: una aproximación desde la fenomenología', 'El ser humano se construye a sí mismo constantemente a través de su relación con la tecnología. La presente ponencia pretende arrojar luz sobre algunos de los efectos de los videojuegos en la construcción de la identidad del jugador, así como de sus procesos de socialización. Este análisis fenomenológico considerará las relaciones en las cuales el individuo interactúa con la tecnología, en un rango que va del casi-yo al casi-otro.', 3, '2010-03-14 16:04:41', '2010-11-10 16:09:30', 1, 0),
(8, 1, 'Un panorama del Social Media en México, 201', 'Un panorama del Social Media en México, 201', 'En el 2009 fuimos testigos de un inusitado auge de Redes Sociales en nuestro paí­s, servicios como Facebook y Twitter de pronto brincaron de la red a ser noticia, a veces no de manera positiva, pero eso sirvé para que miles de personas de pronto se interesaran por estar en la red. De esta manera se genero un aumento exponencial del número de usuarios que utilizan estos servicios, conviertiéndose en objetivo de agencias, medios, marcas, empresas, etc.\r\n\r\n¿Es el Social Media para todas las empresas? ¿Se puede vivir del bloging y las redes sociales? ¿Cuáles son los servicios mí¡s utilizados en México? Esa y otras preguntas trataremos de responderlas en esta charla, además de repasar el panorama de los Social Media en México, sus perspectivas y í¡reas de oportunidad para este aí±o.', 3, '2010-03-14 16:04:41', '2010-11-10 16:07:24', 1, 0),
(36, 1, 'Keynote 1', 'Keynote 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:35:19', '2010-05-04 14:35:19', 1, 0),
(37, 1, 'Keynote 2', 'Keynote 2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:35:37', '2010-05-04 14:35:37', 1, 0),
(38, 1, 'Keynote 3', 'Keynote 3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:35:49', '2010-05-04 14:35:49', 1, 0),
(39, 1, 'Keynote 4', 'Keynote 4', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:35:59', '2010-05-04 14:35:59', 1, 0),
(40, 1, 'Keynote 5', 'Keynote 5', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:36:10', '2010-05-04 14:36:10', 1, 0),
(41, 1, 'Keynote 6', 'Keynote 6', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, '2010-05-04 14:36:18', '2010-05-04 14:36:38', 1, 0),
(55, 1, 'Taller de videojuegos', 'Video', 'asdf', 1, '2010-11-01 13:26:10', '2010-11-01 13:26:10', 1, 0),
(56, 1, 'Android Development', 'Android Development', 'Learn to develop applications for Android.', 1, '2010-11-08 09:32:15', '2010-11-08 09:32:15', 1, 0),
(57, 1, 'Pantallas 3d', 'Pantallas 3d', 'Pantallas 3d', 2, '2010-11-10 15:13:49', '2010-11-10 15:13:49', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `activities_users`
--

CREATE TABLE IF NOT EXISTS `activities_users` (
  `activity_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`activity_id`,`user_id`),
  KEY `activity_id` (`activity_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `activities_users`
--

INSERT INTO `activities_users` (`activity_id`, `user_id`) VALUES
(1, 4),
(2, 9),
(2, 10),
(3, 31),
(3, 32),
(4, 30),
(5, 33),
(6, 35),
(7, 34),
(8, 1),
(8, 2),
(8, 36),
(9, 6),
(10, 7),
(11, 8),
(12, 9),
(13, 11),
(14, 12),
(15, 4),
(16, 5),
(17, 10),
(18, 13),
(19, 14),
(20, 19),
(20, 20),
(21, 21),
(22, 23),
(23, 15),
(24, 16),
(25, 17),
(26, 16),
(27, 18),
(27, 22),
(28, 4),
(29, 25),
(30, 25),
(31, 26),
(32, 27),
(33, 28),
(34, 24),
(35, 24),
(35, 29);

-- --------------------------------------------------------

--
-- Table structure for table `areas`
--

CREATE TABLE IF NOT EXISTS `areas` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(120) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `areas`
--

INSERT INTO `areas` (`id`, `name`, `description`, `deleted`, `active`) VALUES
(1, 'Finances', 'Signup and payment management', 0, 1),
(2, 'Activities', 'Workshops, keynotes, conferences, etc', 0, 1),
(3, 'Image', 'Design and printing', 0, 1),
(4, 'Communication', 'Link between the committee and the participants', 0, 1),
(5, 'Users', 'Users'' management', 0, 1),
(6, 'Logistics', 'Services offered by the event', 0, 1),
(7, 'Settings', 'Site configuration and options', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `areas_groups`
--

CREATE TABLE IF NOT EXISTS `areas_groups` (
  `area_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `areas_groups`
--

INSERT INTO `areas_groups` (`area_id`, `group_id`) VALUES
(1, 7),
(2, 6),
(6, 5);

-- --------------------------------------------------------

--
-- Table structure for table `authake_groups`
--

CREATE TABLE IF NOT EXISTS `authake_groups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `authake_groups`
--

INSERT INTO `authake_groups` (`id`, `name`) VALUES
(1, 'Administrators'),
(3, 'Registered'),
(2, 'User & Group Management'),
(4, 'Everybody'),
(5, 'Logistics Management'),
(6, 'Activities Management'),
(7, 'Finance Management'),
(8, 'Webmaster'),
(9, 'Event Management'),
(10, 'Package Management'),
(11, 'Place Management'),
(12, 'Signup Management'),
(13, 'Discount Management'),
(14, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `authake_groups_users`
--

CREATE TABLE IF NOT EXISTS `authake_groups_users` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `group_id` int(10) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `authake_groups_users`
--

INSERT INTO `authake_groups_users` (`user_id`, `group_id`) VALUES
(46, 7),
(45, 6),
(2, 1),
(4, 1),
(47, 9),
(43, 8),
(44, 5),
(36, 1),
(1, 1),
(49, 10),
(50, 11),
(51, 12),
(52, 13),
(45, 14),
(52, 14),
(47, 14),
(46, 14),
(44, 14),
(49, 14),
(50, 14),
(51, 14),
(43, 14),
(53, 3),
(57, 3);

-- --------------------------------------------------------

--
-- Table structure for table `authake_profiles`
--

CREATE TABLE IF NOT EXISTS `authake_profiles` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(120) collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `display_name` varchar(120) collate utf8_unicode_ci NOT NULL,
  `team_id` int(11) NOT NULL,
  `birthdate` date NOT NULL,
  `organization_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `authake_profiles`
--

INSERT INTO `authake_profiles` (`id`, `user_id`, `first_name`, `last_name`, `display_name`, `team_id`, `birthdate`, `organization_id`, `state_id`) VALUES
(1, 1, 'Francisco', 'Avila', 'elfrank', 6, '2030-06-01', 1, 1),
(2, 2, 'Martin', 'Mora', 'Test 1', 3, '1988-06-01', 1, 1),
(4, 4, 'Maricela', 'Dominguez', 'Test 3', 10, '1988-06-01', 1, 1),
(29, 57, 'Martin', 'Martinez', 'Martin', 0, '2030-01-01', 1, 1),
(8, 39, 'Maria', 'Rodriguez', 'Juan', 6, '1988-06-01', 1, 3),
(7, 38, 'Juan', 'Perez', 'Juan', 6, '1988-06-01', 1, 2),
(6, 37, 'Carlos', 'Lopez', 'Carlos', 4, '1988-06-01', 1, 1),
(28, 56, 'Alfredo', 'Bautista', 'Alfredo', 4, '1988-09-09', 2, 2),
(27, 55, 'Carla', 'Flores', 'Carla', 4, '1988-09-09', 1, 2),
(26, 54, 'Marco', 'Lopez', 'Marco', 4, '1988-09-09', 1, 1),
(10, 41, 'Alberto', 'Santana', 'Beto', 6, '1988-06-01', 1, 5),
(30, 62, 'F', 'G', 'felix', 0, '1990-01-01', 1, 1),
(31, 63, '', '', '', 0, '0000-00-00', 0, 0),
(32, 46, '', '', '', 0, '0000-00-00', 0, 0),
(34, 64, '', '', '', 0, '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `authake_rules`
--

CREATE TABLE IF NOT EXISTS `authake_rules` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(256) character set latin1 NOT NULL COMMENT 'Rule description',
  `group_id` int(10) unsigned NOT NULL default '0',
  `order` int(10) unsigned default NULL,
  `action` varchar(512) character set latin1 default NULL,
  `permission` enum('Deny','Allow') collate utf8_unicode_ci NOT NULL default 'Deny',
  `forward` varchar(64) collate utf8_unicode_ci NOT NULL,
  `message` varchar(512) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `authake_rules`
--

INSERT INTO `authake_rules` (`id`, `name`, `group_id`, `order`, `action`, `permission`, `forward`, `message`) VALUES
(0, 'Allow everything for Administrators', 1, 999999, '*', 'Allow', '', ''),
(2, 'Allow anybody to see the home page, the error page, to register, to log in, see profile and log out', 0, 200, '/ or (/authake)?/user/* or /activities* or /codes* or /contenttypes* or /events* or /packages* or /places* or /schedules* or /teams(/add)?', 'Allow', '', ''),
(3, '(example) Allow anybody to view the rules list', 0, 700, '/authake/rules/index', 'Allow', '', ''),
(4, 'Allow everything for everybody by default', 0, 0, '*', 'Allow', '', ''),
(7, 'Allow Webmaster Actions', 8, 250, '/admin/areas* or /admin/contenttypes* or /admin/menus* or /admin/states*', 'Allow', '', ''),
(5, 'Allow "user & group managers" to edit users, groups and view rules', 2, 800, '/authake(/index)? or /authake/*/index/tableonly or /authake/users/(index|add/?|edit/[0-9]+|view/[0-9]+|delete/[0-9]+) or /authake/groups/(index|add/?|edit/[0-9]+|view/[0-9]+|delete/[0-9]+) or /authake/rules/(index|view/[0-9]+)', 'Allow', '', ''),
(6, 'Display a message for denied admin page', 0, 100, '/authake(/index)? or /authake/users* or /authake/groups* or /authake/rules* or /dashboard* or /admin*', 'Deny', '', 'You are not allowed to access the administration page!'),
(8, 'Allow Activities Management Actions', 6, 251, '/admin/activities* or /admin/places* or /admin/schedules*', 'Allow', '', ''),
(9, 'Allow Logistics Actions', 5, 252, '/admin/activities* or /admin/areas* or /admin/contenttypes* or /admin/event* or /admin/places* or /admin/schedules* or /admin/states* or /admin/teams*', 'Allow', '', ''),
(10, 'Allow Finances Management Actions', 7, 253, '/admin/signups* or /admin/codes* or /admin/coupons* /admin/packages* or /admin/tickets*', 'Allow', '', ''),
(11, 'Allow Events Management Actions', 9, 254, '/admin/events*', 'Allow', '', ''),
(12, 'Allow Package Management Actions', 10, 255, '/admin/packages* or /admin/signups*', 'Allow', '', ''),
(13, 'Allow Places Management Actions', 11, 256, '/admin/places*', 'Allow', '', ''),
(14, 'Allow Signups Management Actions', 12, 257, '/admin/signups* or /admin/packages* or /admin/teams* or /admin/coupons* or /admin/codes*', 'Allow', '', ''),
(15, 'Allow Discount Management Actions', 13, 258, '/admin/coupons* or /admin/codes*', 'Allow', '', ''),
(16, 'Allow Staff Actions', 14, 259, '/dashboard(/)?', 'Allow', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `authake_users`
--

CREATE TABLE IF NOT EXISTS `authake_users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `login` varchar(32) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(128) collate utf8_unicode_ci NOT NULL,
  `emailcheckcode` varchar(128) collate utf8_unicode_ci NOT NULL,
  `passwordchangecode` varchar(128) collate utf8_unicode_ci NOT NULL,
  `disable` tinyint(1) NOT NULL COMMENT 'Disable/enable account',
  `expire_account` date NOT NULL,
  `created` datetime default NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=65 ;

--
-- Dumping data for table `authake_users`
--

INSERT INTO `authake_users` (`id`, `login`, `password`, `email`, `emailcheckcode`, `passwordchangecode`, `disable`, `expire_account`, `created`, `updated`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@mail.com', '', '', 0, '2030-01-01', '0000-00-00 00:00:00', '2010-05-02 23:34:02'),
(2, 'jairsv', 'c3d6054fa0393ef4f66676e26618b5e3', 'jairsv@gmail.com', '', '', 0, '2030-01-01', '2008-01-26 19:08:03', '2008-02-13 12:22:48'),
(4, 'mdominguez', '95e6a007d09887c5681d9b758ad644dd', 'mdominguez@gmail.com', '', '', 0, '2028-01-01', '2008-01-30 23:40:03', '2008-02-13 08:55:03'),
(44, 'logistics', '9b7817dceaaf44106fce1b9357a1ff9a', 'logistics@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:20:45', '2010-05-03 02:20:45'),
(43, 'webmaster', '50a9c7dbf0fa09e8969978317dca12e8', 'webmaster@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:10:17', '2010-05-03 02:10:17'),
(36, 'carlos', 'dc599a9972fde3045dab59dbd1ae170b', 'carlos.lopez.garces@gmail.com', '', '', 0, '2030-01-01', '2010-04-18 18:41:35', '2010-04-18 18:41:35'),
(50, 'places', 'ab7dc89534e36069de69a74fe634aa31', 'places@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:22:43', '2010-05-03 02:22:43'),
(49, 'packages', '2fc9e51174a78dd5bfc57e8e368590b3', 'packages@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:22:31', '2010-05-03 02:22:31'),
(45, 'activities', '609f88983635a66fe4c8570afee066e0', 'activities@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:21:03', '2010-05-03 02:21:03'),
(46, 'finances', '26a72de0d02e0e4e5f615332d61a878e', 'finances@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:21:21', '2010-05-03 02:21:21'),
(47, 'events', '16908b0605f2645dfcb4c3a8d248cef3', 'events@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:21:33', '2010-05-03 02:21:33'),
(51, 'signup', '7d2abf2d0fa7c3a0c13236910f30bc43', 'signup@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:22:53', '2010-05-03 02:22:53'),
(52, 'discount', 'e2dc6c48c56de466f6d13781796abf3d', 'discount@mail.com', '', '', 0, '2030-01-01', '2010-05-03 02:23:25', '2010-05-03 02:23:25'),
(53, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user@mail', '', '', 0, '0000-00-00', '2010-05-03 04:40:03', '2010-05-03 04:40:03'),
(54, 'marco', 'f5888d0bb58d611107e11f7cbc41c97a', 'marco@mail.com', 'f4743d486e73f4b70b081556b91bf59b', '', 0, '0000-00-00', '2010-05-04 04:30:27', '2010-05-04 04:30:27'),
(55, 'carla', '1fa4a2211b4e290f2a066de6b84187ec', 'carla@mail.com', '5ba8418081b7bd2bb91f1a31da6dabe4', '', 0, '0000-00-00', '2010-05-04 04:31:19', '2010-05-04 04:31:19'),
(56, 'alfredo', '5c2bf15004e661d7b7c9394617143d07', 'alfredo@mail.com', '6bf7ed7ed33ce4579944ef5531b88cbc', '', 0, '0000-00-00', '2010-05-04 04:31:42', '2010-05-04 04:31:42'),
(37, 'clopez', '21232f297a57a5a743894a0e4a801fc3', 'clopez@mail.com', '', '', 0, '0000-00-00', '2010-04-30 00:28:00', '2010-04-30 00:28:00'),
(38, 'jperez', '21232f297a57a5a743894a0e4a801fc3', 'jperez@mail.com', '', '', 0, '0000-00-00', '2010-04-30 00:29:10', '2010-04-30 00:29:10'),
(39, 'mrodriguez', '21232f297a57a5a743894a0e4a801fc3', 'mrodriguez@mail.com', '', '', 0, '0000-00-00', '2010-04-30 00:29:28', '2010-04-30 00:29:28'),
(40, 'mramirez', '21232f297a57a5a743894a0e4a801fc3', 'mramirez@mail.com', '\n', '', 0, '0000-00-00', '2010-04-30 00:29:47', '2010-04-30 00:29:47'),
(41, 'asantana', '21232f297a57a5a743894a0e4a801fc3', 'asantana@mail.com', '', '', 0, '0000-00-00', '2010-04-30 00:30:02', '2010-04-30 00:30:02'),
(57, 'martin', '925d7518fc597af0e43f5606f9a51512', 'martin@gmail.com', '', '', 0, '0000-00-00', '2010-10-23 14:37:11', '2010-10-23 14:37:11'),
(63, 'ramiro', '49bbccc812370520878c7f343d48900b', 'ramiro@mail.com', '', '', 0, '0000-00-00', '2010-10-30 01:54:29', '2010-10-30 01:54:29'),
(62, 'felix', '25779f8829ab7a7650e85a4cc871e6ac', 'felix@mail.com', '', '', 0, '0000-00-00', '2010-10-23 18:38:32', '2010-10-23 18:38:32'),
(64, 'marcos', 'c5e3539121c4944f2bbe097b425ee774', 'marcos@mail.com', '59a574f627d5db6cf095daa2ce5cfdb8', '', 0, '0000-00-00', '2010-11-10 14:56:42', '2010-11-10 14:56:42');

-- --------------------------------------------------------

--
-- Table structure for table `codes`
--

CREATE TABLE IF NOT EXISTS `codes` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `coupon_id` int(11) unsigned NOT NULL,
  `user_id` int(11) default NULL,
  `code` varchar(20) character set armscii8 NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `used` enum('yes','no') collate utf8_unicode_ci NOT NULL default 'no',
  `use_date` datetime default NULL,
  `package_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=94 ;

--
-- Dumping data for table `codes`
--

INSERT INTO `codes` (`id`, `coupon_id`, `user_id`, `code`, `discount`, `created`, `modified`, `deleted`, `used`, `use_date`, `package_id`) VALUES
(1, 2, 4, '1', 599.00, '2010-03-16 04:22:12', '2010-05-04 17:28:17', 0, 'yes', '0000-00-00 00:00:00', 6),
(2, 2, 1, '2', 599.00, '2010-03-16 04:22:12', '2010-11-10 15:16:37', 0, 'yes', '0000-00-00 00:00:00', 2),
(3, 2, NULL, '3', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(4, 2, NULL, '4', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(5, 2, NULL, '5', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(6, 2, NULL, '6', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(7, 2, NULL, '7', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(8, 2, NULL, '8', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(9, 2, NULL, '9', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(10, 2, NULL, '10', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(11, 2, NULL, '11', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(12, 2, NULL, '12', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(13, 2, NULL, '13', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(14, 2, NULL, '14', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(15, 2, NULL, '15', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(16, 2, NULL, '16', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(17, 2, NULL, '17', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(18, 2, NULL, '18', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(19, 2, NULL, '19', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(20, 2, NULL, '20', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(21, 2, NULL, '21', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(22, 2, NULL, '22', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(23, 2, NULL, '23', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(24, 2, NULL, '24', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(25, 2, NULL, '25', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(26, 2, NULL, '26', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(27, 2, NULL, '27', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(28, 2, NULL, '28', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(29, 2, NULL, '29', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(30, 2, NULL, '30', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(31, 2, NULL, '31', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(32, 2, NULL, '32', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(33, 2, NULL, '33', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(34, 2, NULL, '34', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(35, 2, NULL, '35', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(36, 2, NULL, '36', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(37, 2, NULL, '37', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(38, 2, NULL, '38', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(39, 2, NULL, '39', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(40, 2, NULL, '40', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(41, 2, NULL, '41', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(42, 2, NULL, '42', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(43, 2, NULL, '43', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(44, 2, NULL, '44', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(45, 2, NULL, '45', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(46, 2, NULL, '46', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(47, 2, NULL, '47', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(48, 2, NULL, '48', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(49, 2, NULL, '49', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(50, 2, NULL, '50', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(51, 2, NULL, '51', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(52, 2, NULL, '52', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(53, 2, NULL, '53', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(54, 2, NULL, '54', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(55, 2, NULL, '55', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(56, 2, NULL, '56', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(57, 2, NULL, '57', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(58, 2, NULL, '58', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(59, 2, NULL, '59', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(60, 2, NULL, '60', 599.00, '2010-03-16 04:22:12', '2010-03-16 04:22:12', 0, 'no', '0000-00-00 00:00:00', NULL),
(61, 1, NULL, '61', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(62, 1, NULL, '62', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(63, 1, NULL, '63', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(64, 1, NULL, '64', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(65, 1, NULL, '65', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(66, 1, NULL, '66', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(67, 1, NULL, '67', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(68, 1, NULL, '68', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(69, 1, NULL, '69', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(70, 1, NULL, '70', 299.00, '2010-03-16 04:23:21', '2010-03-16 04:23:21', 0, 'no', '0000-00-00 00:00:00', NULL),
(71, 1, NULL, '71', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(72, 1, NULL, '72', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(73, 1, NULL, '73', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(74, 1, NULL, '74', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(75, 1, NULL, '75', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(76, 1, NULL, '76', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(77, 1, NULL, '77', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(78, 1, NULL, '78', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(79, 1, NULL, '79', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(80, 1, NULL, '80', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(81, 1, NULL, '81', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(82, 1, NULL, '82', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(83, 1, NULL, '83', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(84, 1, NULL, '84', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(85, 1, NULL, '85', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(86, 1, NULL, '86', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(87, 1, NULL, '87', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(88, 1, NULL, '88', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(89, 1, NULL, '89', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(90, 1, NULL, '90', 599.00, '2010-03-16 04:24:25', '2010-03-16 04:24:25', 0, 'no', '0000-00-00 00:00:00', NULL),
(91, 1, 1, '1024', 0.00, '2010-05-03 23:03:34', '2010-05-04 00:16:41', 0, 'yes', '0000-00-00 00:00:00', 2),
(93, 0, NULL, '', 0.00, '2010-05-04 03:58:46', '2010-05-04 04:00:24', 0, 'yes', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contenttypes`
--

CREATE TABLE IF NOT EXISTS `contenttypes` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(30) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `contenttypes`
--

INSERT INTO `contenttypes` (`id`, `name`, `description`, `created`, `modified`, `deleted`) VALUES
(1, 'Taller', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:01', 0),
(2, 'Conferencia', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:04', 0),
(3, 'Charla', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:07', 0),
(4, 'Evento Social', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:10', 0),
(5, 'Registro', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:13', 0),
(6, 'Break', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:16', 0),
(7, 'Comida', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '0000-00-00 00:00:00', '2010-05-03 05:53:19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(100) character set armscii8 NOT NULL,
  `description` text character set armscii8 NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `percentage` decimal(5,2) NOT NULL default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `name`, `description`, `created`, `modified`, `deleted`, `percentage`) VALUES
(1, '50% discount', 'A discount of 50% off the price of the ticket.', '2010-03-16 04:09:25', '2010-05-03 20:56:13', 0, 50.00),
(2, 'Free Pass', 'A discount of 100% off the price of the ticket.', '2010-03-16 04:09:43', '2010-05-03 20:57:16', 0, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `short_name` varchar(60) collate utf8_unicode_ci NOT NULL,
  `long_name` varchar(120) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `slogan` varchar(255) collate utf8_unicode_ci NOT NULL,
  `place` varchar(60) collate utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `short_name`, `long_name`, `description`, `slogan`, `place`, `start_date`, `end_date`, `created`, `modified`, `active`, `deleted`) VALUES
(1, '10th CISC', '10th Computer Engineering Congress', 'International Symposium of Computer Engineering and Technology', 'Your date with the future', 'ITESM Campus Guadalajara', '2010-03-18', '2010-03-20', '2010-03-14 08:40:15', '2010-11-08 09:24:34', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `instant_payment_notifications`
--

CREATE TABLE IF NOT EXISTS `instant_payment_notifications` (
  `id` char(36) NOT NULL,
  `notify_version` varchar(64) default NULL COMMENT 'IPN Version Number',
  `verify_sign` varchar(127) default NULL COMMENT 'Encrypted string used to verify the authenticityof the tansaction',
  `test_ipn` int(11) default NULL,
  `address_city` varchar(40) default NULL COMMENT 'City of customers address',
  `address_country` varchar(64) default NULL COMMENT 'Country of customers address',
  `address_country_code` varchar(2) default NULL COMMENT 'Two character ISO 3166 country code',
  `address_name` varchar(128) default NULL COMMENT 'Name used with address (included when customer provides a Gift address)',
  `address_state` varchar(40) default NULL COMMENT 'State of customer address',
  `address_status` varchar(20) default NULL COMMENT 'confirmed/unconfirmed',
  `address_street` varchar(200) default NULL COMMENT 'Customer''s street address',
  `address_zip` varchar(20) default NULL COMMENT 'Zip code of customer''s address',
  `first_name` varchar(64) default NULL COMMENT 'Customer''s first name',
  `last_name` varchar(64) default NULL COMMENT 'Customer''s last name',
  `payer_business_name` varchar(127) default NULL COMMENT 'Customer''s company name, if customer represents a business',
  `payer_email` varchar(127) default NULL COMMENT 'Customer''s primary email address. Use this email to provide any credits',
  `payer_id` varchar(13) default NULL COMMENT 'Unique customer ID.',
  `payer_status` varchar(20) default NULL COMMENT 'verified/unverified',
  `contact_phone` varchar(20) default NULL COMMENT 'Customer''s telephone number.',
  `residence_country` varchar(2) default NULL COMMENT 'Two-Character ISO 3166 country code',
  `business` varchar(127) default NULL COMMENT 'Email address or account ID of the payment recipient (that is, the merchant). Equivalent to the values of receiver_email (If payment is sent to primary account) and business set in the Website Payment HTML.',
  `item_name` varchar(127) default NULL COMMENT 'Item name as passed by you, the merchant. Or, if not passed by you, as entered by your customer. If this is a shopping cart transaction, Paypal will append the number of the item (e.g., item_name_1,item_name_2, and so forth).',
  `item_number` varchar(127) default NULL COMMENT 'Pass-through variable for you to track purchases. It will get passed back to you at the completion of the payment. If omitted, no variable will be passed back to you.',
  `quantity` varchar(127) default NULL COMMENT 'Quantity as entered by your customer or as passed by you, the merchant. If this is a shopping cart transaction, PayPal appends the number of the item (e.g., quantity1,quantity2).',
  `receiver_email` varchar(127) default NULL COMMENT 'Primary email address of the payment recipient (that is, the merchant). If the payment is sent to a non-primary email address on your PayPal account, the receiver_email is still your primary email.',
  `receiver_id` varchar(13) default NULL COMMENT 'Unique account ID of the payment recipient (i.e., the merchant). This is the same as the recipients referral ID.',
  `custom` varchar(255) default NULL COMMENT 'Custom value as passed by you, the merchant. These are pass-through variables that are never presented to your customer.',
  `invoice` varchar(127) default NULL COMMENT 'Pass through variable you can use to identify your invoice number for this purchase. If omitted, no variable is passed back.',
  `memo` varchar(255) default NULL COMMENT 'Memo as entered by your customer in PayPal Website Payments note field.',
  `option_name1` varchar(64) default NULL COMMENT 'Option name 1 as requested by you',
  `option_name2` varchar(64) default NULL COMMENT 'Option 2 name as requested by you',
  `option_selection1` varchar(200) default NULL COMMENT 'Option 1 choice as entered by your customer',
  `option_selection2` varchar(200) default NULL COMMENT 'Option 2 choice as entered by your customer',
  `tax` decimal(10,2) default NULL COMMENT 'Amount of tax charged on payment',
  `auth_id` varchar(19) default NULL COMMENT 'Authorization identification number',
  `auth_exp` varchar(28) default NULL COMMENT 'Authorization expiration date and time, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `auth_amount` int(11) default NULL COMMENT 'Authorization amount',
  `auth_status` varchar(20) default NULL COMMENT 'Status of authorization',
  `num_cart_items` int(11) default NULL COMMENT 'If this is a PayPal shopping cart transaction, number of items in the cart',
  `parent_txn_id` varchar(19) default NULL COMMENT 'In the case of a refund, reversal, or cancelled reversal, this variable contains the txn_id of the original transaction, while txn_id contains a new ID for the new transaction.',
  `payment_date` varchar(28) default NULL COMMENT 'Time/date stamp generated by PayPal, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `payment_status` varchar(20) default NULL COMMENT 'Payment status of the payment',
  `payment_type` varchar(10) default NULL COMMENT 'echeck/instant',
  `pending_reason` varchar(20) default NULL COMMENT 'This variable is only set if payment_status=pending',
  `reason_code` varchar(20) default NULL COMMENT 'This variable is only set if payment_status=reversed',
  `remaining_settle` int(11) default NULL COMMENT 'Remaining amount that can be captured with Authorization and Capture',
  `shipping_method` varchar(64) default NULL COMMENT 'The name of a shipping method from the shipping calculations section of the merchants account profile. The buyer selected the named shipping method for this transaction',
  `shipping` decimal(10,2) default NULL COMMENT 'Shipping charges associated with this transaction. Format unsigned, no currency symbol, two decimal places',
  `transaction_entity` varchar(20) default NULL COMMENT 'Authorization and capture transaction entity',
  `txn_id` varchar(19) default '' COMMENT 'A unique transaction ID generated by PayPal',
  `txn_type` varchar(20) default NULL COMMENT 'cart/express_checkout/send-money/virtual-terminal/web-accept',
  `exchange_rate` decimal(10,2) default NULL COMMENT 'Exchange rate used if a currency conversion occured',
  `mc_currency` varchar(3) default NULL COMMENT 'Three character country code. For payment IPN notifications, this is the currency of the payment, for non-payment subscription IPN notifications, this is the currency of the subscription.',
  `mc_fee` decimal(10,2) default NULL COMMENT 'Transaction fee associated with the payment, mc_gross minus mc_fee equals the amount deposited into the receiver_email account. Equivalent to payment_fee for USD payments. If this amount is negative, it signifies a refund or reversal, and either ofthose p',
  `mc_gross` decimal(10,2) default NULL COMMENT 'Full amount of the customer''s payment',
  `mc_handling` decimal(10,2) default NULL COMMENT 'Total handling charge associated with the transaction',
  `mc_shipping` decimal(10,2) default NULL COMMENT 'Total shipping amount associated with the transaction',
  `payment_fee` decimal(10,2) default NULL COMMENT 'USD transaction fee associated with the payment',
  `payment_gross` decimal(10,2) default NULL COMMENT 'Full USD amount of the customers payment transaction, before payment_fee is subtracted',
  `settle_amount` decimal(10,2) default NULL COMMENT 'Amount that is deposited into the account''s primary balance after a currency conversion',
  `settle_currency` varchar(3) default NULL COMMENT 'Currency of settle amount. Three digit currency code',
  `auction_buyer_id` varchar(64) default NULL COMMENT 'The customer''s auction ID.',
  `auction_closing_date` varchar(28) default NULL COMMENT 'The auction''s close date. In the format: HH:MM:SS DD Mmm YY, YYYY PSD',
  `auction_multi_item` int(11) default NULL COMMENT 'The number of items purchased in multi-item auction payments',
  `for_auction` varchar(10) default NULL COMMENT 'This is an auction payment - payments made using Pay for eBay Items or Smart Logos - as well as send money/money request payments with the type eBay items or Auction Goods(non-eBay)',
  `subscr_date` varchar(28) default NULL COMMENT 'Start date or cancellation date depending on whether txn_type is subcr_signup or subscr_cancel',
  `subscr_effective` varchar(28) default NULL COMMENT 'Date when a subscription modification becomes effective',
  `period1` varchar(10) default NULL COMMENT '(Optional) Trial subscription interval in days, weeks, months, years (example a 4 day interval is 4 D',
  `period2` varchar(10) default NULL COMMENT '(Optional) Trial period',
  `period3` varchar(10) default NULL COMMENT 'Regular subscription interval in days, weeks, months, years',
  `amount1` decimal(10,2) default NULL COMMENT 'Amount of payment for Trial period 1 for USD',
  `amount2` decimal(10,2) default NULL COMMENT 'Amount of payment for Trial period 2 for USD',
  `amount3` decimal(10,2) default NULL COMMENT 'Amount of payment for regular subscription  period 1 for USD',
  `mc_amount1` decimal(10,2) default NULL COMMENT 'Amount of payment for trial period 1 regardless of currency',
  `mc_amount2` decimal(10,2) default NULL COMMENT 'Amount of payment for trial period 2 regardless of currency',
  `mc_amount3` decimal(10,2) default NULL COMMENT 'Amount of payment for regular subscription period regardless of currency',
  `recurring` varchar(1) default NULL COMMENT 'Indicates whether rate recurs (1 is yes, blank is no)',
  `reattempt` varchar(1) default NULL COMMENT 'Indicates whether reattempts should occur on payment failure (1 is yes, blank is no)',
  `retry_at` varchar(28) default NULL COMMENT 'Date PayPal will retry a failed subscription payment',
  `recur_times` int(11) default NULL COMMENT 'The number of payment installations that will occur at the regular rate',
  `username` varchar(64) default NULL COMMENT '(Optional) Username generated by PayPal and given to subscriber to access the subscription',
  `password` varchar(24) default NULL COMMENT '(Optional) Password generated by PayPal and given to subscriber to access the subscription (Encrypted)',
  `subscr_id` varchar(19) default NULL COMMENT 'ID generated by PayPal for the subscriber',
  `case_id` varchar(28) default NULL COMMENT 'Case identification number',
  `case_type` varchar(28) default NULL COMMENT 'complaint/chargeback',
  `case_creation_date` varchar(28) default NULL COMMENT 'Date/Time the case was registered',
  `created` datetime default NULL,
  `modified` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instant_payment_notifications`
--

INSERT INTO `instant_payment_notifications` (`id`, `notify_version`, `verify_sign`, `test_ipn`, `address_city`, `address_country`, `address_country_code`, `address_name`, `address_state`, `address_status`, `address_street`, `address_zip`, `first_name`, `last_name`, `payer_business_name`, `payer_email`, `payer_id`, `payer_status`, `contact_phone`, `residence_country`, `business`, `item_name`, `item_number`, `quantity`, `receiver_email`, `receiver_id`, `custom`, `invoice`, `memo`, `option_name1`, `option_name2`, `option_selection1`, `option_selection2`, `tax`, `auth_id`, `auth_exp`, `auth_amount`, `auth_status`, `num_cart_items`, `parent_txn_id`, `payment_date`, `payment_status`, `payment_type`, `pending_reason`, `reason_code`, `remaining_settle`, `shipping_method`, `shipping`, `transaction_entity`, `txn_id`, `txn_type`, `exchange_rate`, `mc_currency`, `mc_fee`, `mc_gross`, `mc_handling`, `mc_shipping`, `payment_fee`, `payment_gross`, `settle_amount`, `settle_currency`, `auction_buyer_id`, `auction_closing_date`, `auction_multi_item`, `for_auction`, `subscr_date`, `subscr_effective`, `period1`, `period2`, `period3`, `amount1`, `amount2`, `amount3`, `mc_amount1`, `mc_amount2`, `mc_amount3`, `recurring`, `reattempt`, `retry_at`, `recur_times`, `username`, `password`, `subscr_id`, `case_id`, `case_type`, `case_creation_date`, `created`, `modified`) VALUES
('4cc3643a-9590-469c-b29e-0bf4bda99328', '2.4', 'Ayc4O9N62I0Dt90jkA9K2kkC0LXwAqIV5wnJC6wCyTvxkBd7OD.CAz9.', 1, 'San Jose', 'United States', 'US', 'John Smith', 'CA', 'confirmed', '123, any street', '95131', 'John', 'Smith', NULL, 'buyer@paypalsandbox.com', 'TESTBUYERID01', 'unverified', NULL, 'US', NULL, NULL, NULL, NULL, 'seller@paypalsandbox.com', 'TESTSELLERID1', 'xyz123', 'abc1234', NULL, NULL, NULL, NULL, NULL, 2.02, NULL, NULL, NULL, NULL, NULL, NULL, '15:35:00 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, NULL, NULL, '010232235', 'cart', NULL, 'USD', 0.44, NULL, 2.06, 3.02, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 17:39:54', '2010-10-23 17:39:54'),
('4cc3655a-83c4-45be-9a8c-0bf4bda99328', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 17:44:42', '2010-10-23 17:44:42'),
('4cc37484-93c0-4ba8-9d72-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 18:49:24', '2010-10-23 18:49:24'),
('4cc374de-d97c-445d-891f-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 18:50:54', '2010-10-23 18:50:54'),
('4cc375cf-cfec-4bcc-a155-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 18:54:55', '2010-10-23 18:54:55'),
('4cc3789a-1d20-4d28-a1f4-0bf4c0a80208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:06:50', '2010-10-23 19:06:50'),
('4cc37955-05ac-43ff-94b0-0bf4c0a80208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:09:57', '2010-10-23 19:09:57'),
('4cc37967-ad84-43b5-91e4-0bf4c0a80208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:10:15', '2010-10-23 19:10:15'),
('4cc379b7-4788-45a2-8a4b-0bf4c0a80208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:11:35', '2010-10-23 19:11:35'),
('4cc379c8-08c0-4ee6-97ad-0bf4c0a80208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:11:52', '2010-10-23 19:11:52'),
('4cc379e5-6018-428c-95e5-0bf4bda99328', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:12:21', '2010-10-23 19:12:21'),
('4cc37a39-8630-488a-8c0e-0bf4bda99328', '2.4', 'AnOz57vfWPfFviBEuW6euL9YOfAGAsy6vRlGG2dd1KQgKClqItmzMXvW', 1, 'San Jose', 'United States', 'US', 'John Smith', 'CA', 'confirmed', '123, any street', '95131', 'John', 'Smith', NULL, 'buyer@paypalsandbox.com', 'TESTBUYERID01', 'unverified', NULL, 'US', NULL, NULL, NULL, NULL, 'seller@paypalsandbox.com', 'TESTSELLERID1', 'xyz123', 'abc1234', NULL, NULL, NULL, NULL, NULL, 2.02, NULL, NULL, NULL, NULL, NULL, NULL, '15:35:00 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, NULL, NULL, '010232235', 'cart', NULL, 'USD', 0.44, NULL, 2.06, 3.02, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:13:45', '2010-10-23 19:13:45'),
('4cc37a40-a6e0-44be-bfae-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:13:52', '2010-10-23 19:13:52'),
('4cc37c50-5190-4b16-9fa3-0bf4bda99328', '2.4', 'AiPC9BjkCyDFQXbSkoZcgqH3hpacAefNIP-L6nFoboh90-LNHSmKUg63', 1, 'San Jose', 'United States', 'US', 'John Smith', 'CA', 'confirmed', '123, any street', '95131', 'John', 'Smith', NULL, 'buyer@paypalsandbox.com', 'TESTBUYERID01', 'unverified', NULL, 'US', NULL, NULL, NULL, NULL, 'seller@paypalsandbox.com', 'TESTSELLERID1', 'xyz123', 'abc1234', NULL, NULL, NULL, NULL, NULL, 2.02, NULL, NULL, NULL, NULL, NULL, NULL, '15:35:00 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, NULL, NULL, '010232235', 'cart', NULL, 'USD', 0.44, NULL, 2.06, 3.02, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:22:40', '2010-10-23 19:22:40'),
('4cc37cea-18e4-4c1f-952f-0bf4bda99328', '2.4', 'AFcWxV21C7fd0v3bYYYRCpSSRl31AwltIe7j-9T3BKJMvZ.eGOXz6dno', 1, 'San Jose', 'United States', 'US', 'John Smith', 'CA', 'confirmed', '123, any street', '95131', 'John', 'Smith', NULL, 'buyer@paypalsandbox.com', 'TESTBUYERID01', 'unverified', NULL, 'US', NULL, NULL, NULL, NULL, 'seller@paypalsandbox.com', 'TESTSELLERID1', 'xyz123', 'abc1234', NULL, NULL, NULL, NULL, NULL, 2.02, NULL, NULL, NULL, NULL, NULL, NULL, '15:35:00 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, NULL, NULL, '010232235', 'cart', NULL, 'USD', 0.44, NULL, 2.06, 3.02, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:25:14', '2010-10-23 19:25:14'),
('4cc37d55-e290-49b6-a162-0bf4bda99328', '2.4', 'AQNJVjN8b2XPjAhzZfYWKwZ37VQuAMf5mLKSxv2cJtvNBmOg1HUbJnZa', 1, 'San Jose', 'United States', 'US', 'John Smith', 'CA', 'confirmed', '123, any street', '95131', 'John', 'Smith', NULL, 'buyer@paypalsandbox.com', 'TESTBUYERID01', 'unverified', NULL, 'US', NULL, NULL, NULL, NULL, 'seller@paypalsandbox.com', 'TESTSELLERID1', 'xyz123', 'abc1234', NULL, NULL, NULL, NULL, NULL, 2.02, NULL, NULL, NULL, NULL, NULL, NULL, '15:35:00 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, NULL, NULL, '010232235', 'cart', NULL, 'USD', 0.44, NULL, 2.06, 3.02, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:27:01', '2010-10-23 19:27:01'),
('4cc37d90-388c-4bf2-9020-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:28:00', '2010-10-23 19:28:00'),
('4cc37db5-ba4c-4805-9da7-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:28:37', '2010-10-23 19:28:37'),
('4cc37dd5-4408-4872-a1dc-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:29:09', '2010-10-23 19:29:09'),
('4cc37dfb-847c-4f04-a7ab-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:29:47', '2010-10-23 19:29:47'),
('4cc37e21-3884-4fe6-b03b-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:30:25', '2010-10-23 19:30:25'),
('4cc37e2d-6e14-4c9f-89ec-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:30:37', '2010-10-23 19:30:37'),
('4cc37f47-8f34-43b7-9d09-0bf4bda99328', '3.0', 'AsHQRkcKW-wFgMHHT1XJRSDHi9hJA7hUvvQfekoUSVSkS1xHZT2J-RpP', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '29', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '17:35:05 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '3DH07801C6799311M', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:35:19', '2010-10-23 19:35:19'),
('4cc380a9-b910-4f87-9c10-0bf4bda99328', '3.0', 'A2oW3T4m826QUvvljOrYZ3hqgf-sAgZdKZWFVV4aYiSQoUmRbOZKW1qT', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package C', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '29', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '17:41:05 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '5JM4773488800754L', 'web_accept', NULL, 'USD', 23.21, 790.00, NULL, NULL, 23.21, 790.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:41:13', '2010-10-23 19:41:13'),
('4cc380ea-fc08-4e79-81bb-0bf4bda99328', '3.0', 'AFcWxV21C7fd0v3bYYYRCpSSRl31AtPQO4nzOpJTW1BexC7c4lQspX-d', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package C', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '29', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '17:42:10 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '98B2985596440354H', 'web_accept', NULL, 'USD', 23.21, 790.00, NULL, NULL, 23.21, 790.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:42:18', '2010-10-23 19:42:18'),
('4cc38172-07a0-4383-b155-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:44:34', '2010-10-23 19:44:34'),
('4cc38182-7b94-4190-bb6a-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:44:50', '2010-10-23 19:44:50'),
('4cc38190-4d8c-403b-81f6-0bf4c0a80208', '3.0', 'Af92RUiTAY6ass3LI.AI9hDxtHeOAOAphXdYF51O8CFZ4S0JaGTsSrKm', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package A', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:44:33 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '6D152791UX5355626', 'web_accept', NULL, 'USD', 12.77, 430.00, NULL, NULL, 12.77, 430.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:45:04', '2010-10-23 19:45:04'),
('4cc381de-6074-46dc-94b1-0bf4bda99328', '3.0', 'ABT1HGUbRm9rAoQNWHdbVEU-pRtmAT5Upr1kpinmjkrvP0MifvP0x3Lt', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'event_1287871650_per@danielvaldivia.com', 'FAX7UMLZKLANE', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package D', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '29', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '17:46:17 Oct 23, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '9UP96677X4693540T', 'web_accept', NULL, 'USD', 1.46, 40.00, NULL, NULL, 1.46, 40.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-10-23 19:46:22', '2010-10-23 19:46:22'),
('4ccf114b-5198-42a4-a059-0cfd43cd3343', '3.0', 'AsdgbeVY3lvAWtQAZL25hQGwRw11Ax1ZHZZ7uf.w5srfaKR5dY5mxR8d', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'pevent_1288633787_per@danielvaldivia.com', 'F87UUAFZWGAV8', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package R', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '1', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '12:12:54 Nov 01, 2010 PDT', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '7UK518614V173430V', 'web_accept', NULL, 'USD', 1.46, 40.00, NULL, NULL, 1.46, 40.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-11-01 12:13:15', '2010-11-01 12:13:15'),
('4cdb2ade-f5f4-4175-aac2-17bc43cd3343', '3.0', 'ACUe-E7Hjxmeel8FjYAtjnx-yjHAAzfLL6palvWO4Y0sJIGOn5rsGE7b', 1, 'San Jose', 'United States', 'US', 'Test User', 'CA', 'confirmed', '1 Main St', '95131', 'Test', 'User', NULL, 'pevent_1288633787_per@danielvaldivia.com', 'F87UUAFZWGAV8', 'verified', NULL, 'US', 'psell_1287872435_biz@danielvaldivia.com', 'Package R', '', '1', 'psell_1287872435_biz@danielvaldivia.com', 'JN6WTNH46NXZL', '1', NULL, NULL, NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, '15:29:28 Nov 10, 2010 PST', 'Completed', 'instant', NULL, NULL, NULL, NULL, 0.00, NULL, '3CK64612HW246663D', 'web_accept', NULL, 'USD', 1.46, 40.00, NULL, NULL, 1.46, 40.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-11-10 15:29:34', '2010-11-10 15:29:34');

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE IF NOT EXISTS `memberships` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL,
  `team_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`id`, `profile_id`, `team_id`, `created`, `modified`) VALUES
(3, 4, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(120) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `area_id` int(11) NOT NULL,
  `url` varchar(120) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  `deleted` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `description`, `area_id`, `url`, `active`, `deleted`) VALUES
(1, 'Activities', 'Activities Management.', 2, 'activities', 1, 0),
(2, 'Users', 'Users Management.', 5, 'users', 1, 0),
(3, 'Groups', 'Groups Management.', 5, 'groups', 1, 0),
(4, 'Rules', 'Rules Management.', 5, 'rules', 1, 0),
(5, 'Areas', 'Areas Management.', 6, 'areas', 1, 0),
(6, 'Codes', 'Codes Management.', 1, 'codes', 1, 0),
(7, 'Content Types', 'Content Types Management.', 2, 'contenttypes', 1, 0),
(8, 'Coupons', 'Coupons Management.', 1, 'coupons', 1, 0),
(9, 'Event', 'Event Management.', 6, 'events', 1, 0),
(10, 'Menus', 'Menus Management.', 7, 'menus', 1, 0),
(11, 'Places', 'Places Management.', 2, 'places', 1, 0),
(12, 'Schedules', 'Schedules Management.', 2, 'schedules', 1, 0),
(13, 'States', 'States Management.', 7, 'states', 1, 0),
(14, 'Teams', 'Teams Management.', 5, 'teams', 1, 0),
(15, 'Profiles', 'Profiles Management.', 5, 'profiles', 1, 0),
(16, 'Packages', 'Package Management.', 1, 'packages', 1, 0),
(17, 'Signups', 'Signup Management.', 1, 'packages/signups', 1, 0),
(19, 'Tickets', 'Messages sent from users.', 4, 'tickets', 1, 0),
(21, 'Twitter', 'Social communication', 4, 'tweets', 1, 0),
(22, 'Transport Services', 'Transport Services Management.', 6, 'transports', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(120) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `name`) VALUES
(1, 'ITESM');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) character set latin1 NOT NULL,
  `description` text character set latin1 NOT NULL,
  `price` decimal(10,2) NOT NULL default '0.00',
  `qty` int(11) NOT NULL default '0',
  `event_id` int(11) NOT NULL,
  `created` datetime default NULL,
  `modified` datetime default NULL,
  `sales_end` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `description`, `price`, `qty`, `event_id`, `created`, `modified`, `sales_end`) VALUES
(2, 'Package A', 'Signup package A.', 430.00, 50, 1, '2010-04-17 20:30:05', '2010-05-02 23:25:43', '2010-12-01 12:00:00'),
(3, 'Package C', 'Signup package C.', 790.00, 20, 1, '2010-04-17 20:30:58', '2010-05-02 01:17:58', '2010-12-01 12:00:00'),
(4, 'Package D', 'Signup package D.', 40.00, 10, 1, '2010-04-17 20:36:08', '2010-05-02 01:18:04', '2010-12-01 12:00:00'),
(6, 'Package E', 'Signup package E.', 410.00, 5, 1, '2010-04-17 20:38:18', '2010-05-02 01:18:11', '2010-12-01 12:00:00'),
(12, 'Package H', 'Signup pack...', 600.00, 0, 1, '2010-04-17 23:40:49', NULL, '2010-12-01 12:00:00'),
(13, 'Package R', 'Signup package R.', 40.00, 12, 1, '2010-04-18 19:15:23', NULL, '2010-12-01 12:00:00'),
(14, 'Package Z', 'Signup package Z.', 1000.00, 22, 1, '2010-04-21 04:06:46', '2010-05-02 01:18:18', '2009-12-01 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `packages_profiles`
--

CREATE TABLE IF NOT EXISTS `packages_profiles` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `package_id` int(10) unsigned NOT NULL,
  `profile_id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `packages_profiles`
--


-- --------------------------------------------------------

--
-- Table structure for table `paypal_items`
--

CREATE TABLE IF NOT EXISTS `paypal_items` (
  `id` varchar(36) NOT NULL,
  `instant_payment_notification_id` varchar(36) NOT NULL,
  `item_name` varchar(127) default NULL,
  `item_number` varchar(127) default NULL,
  `quantity` varchar(127) default NULL,
  `mc_gross` float(10,2) default NULL,
  `mc_shipping` float(10,2) default NULL,
  `mc_handling` float(10,2) default NULL,
  `tax` float(10,2) default NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paypal_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `slots` int(11) NOT NULL default '30',
  `computers` int(11) NOT NULL default '0',
  `computer_room` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `name`, `description`, `slots`, `computers`, `computer_room`, `created`, `modified`, `deleted`) VALUES
(1, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 18, 0, 1, '2010-03-14 19:21:51', '2010-10-23 15:07:19', 0),
(2, 'Laboratorio Mocap', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 15, 0, 0, '2010-03-14 19:21:51', '2010-05-03 07:03:02', 0),
(3, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:22:29', '2010-10-23 15:07:40', 0),
(4, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:22:29', '2010-10-23 15:07:50', 0),
(5, 'Laboratorio Multimedios', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 27, 27, 1, '2010-03-14 19:23:17', '2010-05-03 07:03:12', 0),
(6, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:23:17', '2010-10-23 15:08:01', 0),
(7, 'Auditorio 2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 200, 0, 0, '2010-03-14 19:24:55', '2010-05-03 07:03:19', 0),
(8, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:24:55', '2010-10-23 15:08:16', 0),
(9, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:25:37', '2010-10-23 15:08:58', 0),
(10, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:25:37', '2010-10-23 15:09:09', 0),
(11, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:26:14', '2010-10-23 15:09:20', 0),
(12, 'Sal', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:26:14', '2010-10-23 15:10:06', 0),
(13, 'IBM Guadalajara', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 50, 0, 0, '2010-03-14 19:26:56', '2010-05-03 07:03:41', 0),
(14, 'SalÃƒÂ³n 4103', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:26:56', '2010-05-03 07:03:45', 0),
(15, 'SalÃƒÂ³n 5101', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:27:29', '2010-05-03 07:03:48', 0),
(16, 'SalÃƒÂ³n 5202', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:27:29', '2010-05-03 07:03:51', 0),
(17, 'SalÃƒÂ³n 2409', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:28:14', '2010-05-03 07:03:55', 0),
(18, 'SalÃƒÂ³n 5201', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:28:14', '2010-05-03 07:03:58', 0),
(19, 'SalÃƒÂ³n 2402', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:29:02', '2010-05-03 07:04:01', 0),
(20, 'SalÃƒÂ³n 3307', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:29:02', '2010-05-03 07:04:04', 0),
(21, 'SalÃƒÂ³n 4103', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:29:35', '2010-05-03 07:04:08', 0),
(22, 'SalÃƒÂ³n 3307', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:29:35', '2010-05-03 07:04:11', 0),
(23, 'SalÃƒÂ³n 2301', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:52:47', '2010-05-03 07:04:14', 0),
(24, 'SalÃƒÂ³n 2405', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:52:47', '2010-05-03 07:04:17', 0),
(25, 'SalÃƒÂ³n 2103', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 30, 0, 0, '2010-03-14 19:53:04', '2010-05-03 07:04:20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE IF NOT EXISTS `schedules` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `activity_id` int(11) unsigned NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `place_id` int(11) NOT NULL,
  `slots` int(11) unsigned NOT NULL,
  `current_slots` int(11) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=83 ;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `activity_id`, `start_date`, `end_date`, `place_id`, `slots`, `current_slots`, `status`, `created`, `modified`, `deleted`) VALUES
(1, 9, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 12, 32, 0, 1, '2010-03-14 16:32:44', '2010-05-04 15:21:09', 0),
(2, 9, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 12, 32, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:19:42', 0),
(3, 10, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 5, 27, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:17:27', 0),
(6, 11, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 10, 24, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(8, 12, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 6, 20, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(9, 13, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 11, 14, 0, 1, '2010-03-14 16:32:44', '2010-05-04 13:49:51', 0),
(10, 13, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 11, 14, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(12, 14, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 15, 30, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(14, 15, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 2, 15, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(15, 16, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 3, 15, 0, 1, '2010-03-14 16:32:44', '2010-05-04 13:53:50', 0),
(17, 17, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 4, 20, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(20, 18, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 5, 12, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(21, 19, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 8, 28, 0, 1, '2010-03-14 16:32:44', '2010-05-04 13:54:05', 0),
(22, 19, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 9, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(23, 20, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 7, 200, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:17:06', 0),
(24, 20, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 7, 200, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(26, 21, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 14, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(27, 22, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 21, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(29, 23, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 1, 26, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:17:39', 0),
(30, 23, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 1, 26, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:18:56', 0),
(31, 24, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 18, 24, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:28:53', 0),
(33, 25, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 17, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(34, 25, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 17, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(36, 26, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 18, 24, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:19:13', 0),
(37, 27, '2010-03-18 17:00:00', '2010-03-18 19:15:00', 13, 50, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(38, 27, '2010-03-19 17:00:00', '2010-03-19 19:15:00', 13, 50, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(39, 28, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 22, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(41, 29, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 16, 24, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(44, 30, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 16, 24, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(45, 31, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 23, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(46, 31, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 23, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(47, 32, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 19, 32, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(48, 32, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 19, 32, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(49, 33, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 25, 14, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(50, 33, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 25, 14, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(51, 34, '2010-03-18 16:00:00', '2010-03-18 19:15:00', 15, 30, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:18:20', 0),
(54, 35, '2010-03-19 16:00:00', '2010-03-19 19:15:00', 22, 28, 0, 1, '2010-03-14 16:32:44', '2010-05-04 14:19:27', 0),
(55, 1, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(57, 2, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(60, 3, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 200, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(62, 4, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(64, 5, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 200, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(66, 6, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 50, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(67, 7, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 28, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(69, 8, '2010-03-20 10:45:00', '2010-03-20 12:15:00', 1, 80, 0, 1, '2010-03-14 16:32:44', '2010-03-14 16:32:44', 0),
(71, 36, '2010-03-18 10:00:00', '2010-03-18 11:30:00', 1, 700, 0, 1, '2010-05-04 14:39:07', '2010-05-04 16:08:26', 0),
(72, 37, '2010-05-04 15:29:00', '2010-05-04 15:29:00', 1, 700, 0, 1, '2010-05-04 15:29:38', '2010-05-04 16:08:26', 0),
(73, 38, '2010-05-04 15:29:00', '2010-05-04 15:29:00', 1, 700, 0, 1, '2010-05-04 15:29:48', '2010-05-04 16:08:26', 0),
(74, 39, '2010-05-04 15:29:00', '2010-05-04 15:29:00', 1, 700, 0, 1, '2010-05-04 15:29:57', '2010-05-04 16:08:26', 0),
(75, 40, '2010-05-04 15:29:00', '2010-05-04 15:29:00', 1, 700, 0, 1, '2010-05-04 15:30:06', '2010-05-04 16:08:26', 0),
(76, 41, '2010-05-04 15:30:00', '2010-05-04 15:30:00', 1, 700, 0, 1, '2010-05-04 15:30:17', '2010-05-04 16:08:26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedules_users`
--

CREATE TABLE IF NOT EXISTS `schedules_users` (
  `schedule_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`schedule_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schedules_users`
--

INSERT INTO `schedules_users` (`schedule_id`, `user_id`) VALUES
(1, 1),
(6, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1);

-- --------------------------------------------------------

--
-- Table structure for table `signups`
--

CREATE TABLE IF NOT EXISTS `signups` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `profile_id` int(10) unsigned NOT NULL,
  `package_id` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `paid` enum('yes','no') character set latin1 NOT NULL default 'no',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`profile_id`,`package_id`),
  KEY `user_package` (`profile_id`,`package_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=60 ;

--
-- Dumping data for table `signups`
--

INSERT INTO `signups` (`id`, `profile_id`, `package_id`, `created`, `modified`, `paid`) VALUES
(35, 6, 2, '2010-04-30 00:53:09', '2010-04-30 00:53:09', 'no'),
(36, 7, 2, '2010-04-30 00:53:12', '2010-04-30 00:53:12', 'no'),
(37, 8, 2, '2010-04-30 00:53:15', '2010-04-30 00:53:15', 'no'),
(38, 9, 2, '2010-04-30 00:53:18', '2010-04-30 00:53:18', 'no'),
(39, 10, 2, '2010-04-30 00:53:22', '2010-04-30 00:53:22', 'no'),
(40, 0, 13, '2010-05-03 23:00:11', '2010-05-03 23:00:11', 'no'),
(41, 0, 13, '2010-05-04 00:15:57', '2010-05-04 00:15:57', 'no'),
(42, 0, 13, '2010-05-04 00:16:41', '2010-05-04 00:16:41', 'no'),
(43, 0, 3, '2010-05-04 03:58:46', '2010-05-04 03:58:46', 'no'),
(44, 0, 4, '2010-05-04 04:00:24', '2010-05-04 04:00:24', 'no'),
(45, 0, 6, '2010-05-04 17:28:17', '2010-05-04 17:28:17', 'no'),
(46, 44, 0, '2010-10-23 19:06:50', '2010-10-23 19:06:50', 'no'),
(47, 44, 0, '2010-10-23 19:09:58', '2010-10-23 19:09:58', 'no'),
(48, 44, 0, '2010-10-23 19:10:15', '2010-10-23 19:10:15', 'no'),
(49, 44, 0, '2010-10-23 19:11:35', '2010-10-23 19:11:35', 'no'),
(50, 44, 0, '2010-10-23 19:11:52', '2010-10-23 19:11:52', 'no'),
(51, 44, 0, '2010-10-23 19:12:21', '2010-10-23 19:12:21', 'no'),
(52, 0, 2, '2010-10-23 19:30:25', '2010-10-23 19:30:25', 'no'),
(53, 0, 2, '2010-10-23 19:30:37', '2010-10-23 19:30:37', 'no'),
(54, 29, 2, '2010-10-23 19:35:19', '2010-10-23 19:35:19', 'no'),
(55, 29, 3, '2010-10-23 19:42:19', '2010-10-23 19:42:19', 'no'),
(56, 29, 4, '2010-10-23 19:46:22', '2010-10-23 19:46:22', 'no'),
(57, 1, 13, '2010-11-01 12:13:17', '2010-11-01 12:13:17', 'no'),
(58, 0, 13, '2010-11-10 15:16:37', '2010-11-10 15:16:37', 'no'),
(59, 1, 13, '2010-11-10 15:29:34', '2010-11-10 15:29:34', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`) VALUES
(1, 'Aguascalientes'),
(2, 'Baja California'),
(3, 'Baja California Sur'),
(4, 'Campeche'),
(5, 'Chiapas'),
(6, 'Chihuahua'),
(7, 'Coahuila'),
(8, 'Colima'),
(9, 'Distrito Federal'),
(10, 'Durango'),
(11, 'Estado de MÃƒÆ’Ã‚Â©x'),
(12, 'Guanajuato'),
(13, 'Guerrero'),
(14, 'Hidalgo'),
(15, 'Jalisco'),
(16, 'MichoacÃƒÆ’Ã‚Â¡n'),
(17, 'Morelos'),
(18, 'Nayarit'),
(19, 'Nuevo LeÃƒÆ’Ã‚Â³n'),
(20, 'Oaxaca'),
(21, 'Puebla'),
(22, 'QuerÃƒÆ’Ã‚Â©taro'),
(23, 'Quintana Roo'),
(24, 'San Luis PotosÃƒÆ’Ã‚Â'),
(25, 'Sinaloa'),
(26, 'Sonora'),
(27, 'Tabasco'),
(28, 'Tamaulipas'),
(29, 'Tlaxcala'),
(30, 'Veracruz'),
(31, 'YucatÃƒÆ’Ã‚Â¡n'),
(32, 'Zacatecas');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
  `id` int(11) NOT NULL auto_increment,
  `profile_id` int(11) NOT NULL,
  `name` varchar(60) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `profile_id`, `name`, `created`, `modified`, `deleted`) VALUES
(1, 4, '01 Nogales', '2010-03-16 02:04:06', '2010-05-04 05:29:20', 0),
(2, 28, '02 Apan', '2010-03-16 04:18:28', '2010-05-04 05:29:46', 0),
(3, 1, '03 Colima Vallejo', '2010-03-16 04:18:42', '2010-03-16 04:18:42', 0),
(4, 1, '04 Celaya', '2010-03-16 04:18:54', '2010-03-16 04:18:54', 0),
(5, 1, '05 Unisierra Jorge', '2010-03-16 04:19:16', '2010-03-16 04:19:16', 0),
(6, 1, '06 Laguna', '2010-03-16 04:19:27', '2010-03-16 04:19:27', 0),
(7, 1, '06B Toluca', '2010-03-16 04:19:44', '2010-03-16 04:19:44', 0),
(9, 1, '08 UTSOE', '2010-03-16 04:20:13', '2010-03-16 04:20:13', 0),
(10, 1, '09 Cd. Cuah', '2010-03-16 04:20:30', '2010-03-16 04:20:30', 0),
(11, 1, '10 Colima Rodolfo', '2010-03-16 04:20:44', '2010-03-16 04:20:44', 0),
(12, 1, '12 Laguna Rodolfo', '2010-03-16 04:20:59', '2010-03-16 04:20:59', 0),
(13, 1, '15 Tacambaro', '2010-03-16 04:22:52', '2010-03-16 04:22:52', 0),
(14, 1, '16 Tepic Diana', '2010-03-16 04:23:02', '2010-03-16 04:23:02', 0),
(25, 2, '03 Colima Vallejo', '2010-05-04 04:29:14', '2010-05-04 04:29:14', 0),
(28, 26, '05 Unisierra Jorge', '2010-05-04 04:36:27', '2010-05-04 04:36:27', 0),
(29, 27, '07 Laguna', '2010-05-04 04:36:34', '2010-05-04 04:36:34', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL auto_increment,
  `area_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `subject` varchar(100) character set latin1 NOT NULL,
  `message` text character set latin1 NOT NULL,
  `reply` text character set latin1 NOT NULL,
  `created` datetime NOT NULL,
  `checked` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `area_id`, `profile_id`, `subject`, `message`, `reply`, `created`, `checked`) VALUES
(1, 1, 4, 'Question', 'Price of tickets?', 'Checa la sección de paquetes en la página principal', '2010-10-01 00:00:00', 0),
(2, 2, 7, 'Account not working', 'My account is not working.', '', '2010-10-01 00:00:00', 0),
(5, 1, 29, 'Price of hotel Y', 'What is the cost of staying one night in hotel Y?', 'Dear participant, the price of hotel Y is $100 per night.', '2010-10-30 01:10:59', 0),
(6, 2, 29, 'Precioes', 'asdf', '', '2010-11-01 13:30:00', 0),
(7, 1, 1, 'Price of tickets', 'I need the price of tickets.', 'Refer to the web site', '2010-11-10 14:59:10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `transports`
--

CREATE TABLE IF NOT EXISTS `transports` (
  `id` int(11) NOT NULL auto_increment,
  `company` varchar(255) NOT NULL,
  `number_of_units` int(11) NOT NULL,
  `type_of_unit` varchar(255) NOT NULL,
  `capacity_of_unit` int(11) NOT NULL,
  `price_per_unit` decimal(10,0) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `transports`
--

INSERT INTO `transports` (`id`, `company`, `number_of_units`, `type_of_unit`, `capacity_of_unit`, `price_per_unit`) VALUES
(1, 'ETN', 6, 'Bus', 45, 500),
(2, 'Mexicana', 1, 'Air plane', 75, 200),
(3, 'RadioTaxi', 12, 'Car', 4, 35),
(4, 'Primera Plus', 7, 'Bus', 50, 900);

-- --------------------------------------------------------

--
-- Table structure for table `twitter_accounts`
--

CREATE TABLE IF NOT EXISTS `twitter_accounts` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(254) collate utf8_unicode_ci NOT NULL,
  `profile_pic` varchar(254) collate utf8_unicode_ci NOT NULL,
  `access_token` varchar(254) collate utf8_unicode_ci NOT NULL,
  `access_token_secret` varchar(254) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `twitter_accounts`
--

INSERT INTO `twitter_accounts` (`id`, `username`, `profile_pic`, `access_token`, `access_token_secret`) VALUES
(4, 'eventwebmanager', 'http://s.twimg.com/a/1288374569/images/default_profile_4_normal.png', '209958914-sNoAoYFE1u5OJMBr5eZ5ViuNPMurcENJb4P2txrX', 'oRVNWaDQLgp0dXlwXyjMsVoeJAnoNZu49HpkZh9tg'),
(3, 'clopezgarces', 'http://s.twimg.com/a/1288305442/images/default_profile_3_normal.png', '129403403-Pj6mdUwZdE6YbvpKdZJHWUr7GLHPeRzVFJH8nuFe', '29gW8P2sJuL1g2uuKz4a1ICRVQT6fwbXofHpzQQinA');
